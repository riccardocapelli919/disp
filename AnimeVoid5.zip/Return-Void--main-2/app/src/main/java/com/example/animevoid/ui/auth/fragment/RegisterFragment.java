package com.example.animevoid.ui.auth.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.animevoid.R;
import com.example.animevoid.utility.AnimeVoidText;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

public class RegisterFragment extends Fragment {

    private AuthViewModel viewModel;

    public RegisterFragment() {
        // Required empty public constructor
    }
    public static RegisterFragment newInstance(String param1, String param2) {
        RegisterFragment fragment = new RegisterFragment();
        //Bundle args = new Bundle();
        //args.putString(ARG_PARAM1, param1);
        //args.putString(ARG_PARAM2, param2);
        //fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_register, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(AuthViewModel.class);

        // Modifica colori titolo e sub titolo
        TextView title = view.findViewById(R.id.titleText);
        AnimeVoidText.apply(title);

        TextView title1 = view.findViewById(R.id.loginSubtitleText);
        AnimeVoidText.apply1(title1);

        // Registrazione account (username, email e password)

        MaterialButton btnRegister = view.findViewById(R.id.RegisterButton);

        TextInputEditText InputUsername = view.findViewById(R.id.usernameEditText);

        TextInputEditText InputEmail = view.findViewById(R.id.emailEditText);

        TextInputEditText InputPassword = view.findViewById(R.id.passwordEditText);

        TextInputEditText ConfirmPassword = view.findViewById(R.id.passwordConfirmText);

        MaterialButton btnGoogle = view.findViewById(R.id.googleRegistrationButton);

        /*
        AuthManager auth = AuthManager.getInstance();

        btnRegister.setOnClickListener(v -> {
            String username = InputUsername.getText().toString();
            String email = InputEmail.getText().toString();
            String pass = InputPassword.getText().toString();
            String pass2 = ConfirmPassword.getText().toString();

            if (!pass.equals(pass2)) {
                // mostra errore e return
                if (v != null) {
                    Snackbar sb = Snackbar.make(v,
                            "Password deve essere uguale",
                            Snackbar.LENGTH_LONG);

                    sb.getView().setTranslationY(200); // spostalo verso il basso se serve
                    ((FrameLayout.LayoutParams) sb.getView().getLayoutParams()).gravity = Gravity.TOP;

                    sb.show();
                }
                return;
            }

            auth.signUpWithEmail(requireActivity(), username, email, pass, new AuthManager.AuthCallback() {
                @Override public void onSuccess(@NonNull FirebaseUser user) {
                    // Registrato e loggato. user.getDisplayName() contiene lo username.
                    Intent i = new Intent(requireContext(), SecondActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);

                }
                @Override public void onError(@NonNull String msg, @Nullable Exception e) {
                    // mostra msg
                    if (e != null) {
                        Log.e("RegisterFragment", "signUp error: " + msg, e);
                    } else {
                        Log.e("RegisterFragment", "signUp error: " + msg);
                    }

                    if (v != null) {
                        Snackbar sb = Snackbar.make(v, msg, Snackbar.LENGTH_LONG);
                        sb.getView().setTranslationY(200);
                        ((FrameLayout.LayoutParams) sb.getView().getLayoutParams()).gravity = Gravity.TOP;
                        sb.show();
                    }
                }
            });
        });

        // Registrazione tramite Google

        btnGoogle.setOnClickListener(v -> {
            auth.signInWithGoogle(requireActivity(), new AuthManager.AuthCallback() {
                @Override public void onSuccess(@NonNull FirebaseUser user) {
                    // Entra nell'app
                    Intent i = new Intent(requireContext(), SecondActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                }
                @Override public void onError(@NonNull String msg, @Nullable Exception e) {
                    // mostra msg
                    if (v != null) {
                        Snackbar sb = Snackbar.make(v, msg, Snackbar.LENGTH_LONG);
                        sb.getView().setTranslationY(200);
                        ((FrameLayout.LayoutParams) sb.getView().getLayoutParams()).gravity = Gravity.TOP;
                        sb.show();
                    }
                }
            });
        }); */

        btnRegister.setOnClickListener(v -> {
            String username = InputUsername.getText() != null ? InputUsername.getText().toString() : "";
            String email = InputEmail.getText() != null ? InputEmail.getText().toString() : "";
            String pass = InputPassword.getText() != null ? InputPassword.getText().toString() : "";
            String pass2 = ConfirmPassword.getText() != null ? ConfirmPassword.getText().toString() : "";
            viewModel.registerWithEmail(requireActivity(), username, email, pass, pass2);
        });

        // Registrazione con Google

        btnGoogle.setOnClickListener(v -> viewModel.loginWithGoogle(requireActivity()));

        // Osservazione Stato (Disabilito i bottoni se è in loading)

        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            boolean enabled = isLoading == null || !isLoading;
            btnRegister.setEnabled(enabled);
            btnGoogle.setEnabled(enabled);
        });

        // Osservazione messaggi (errori per la maggioranza dei casi)

        viewModel.getMessage().observe(getViewLifecycleOwner(), msg -> {
            if (msg == null) return;
            showTopSnackbar(view, msg);
            viewModel.clearMessage();
        });

        // Navigazione

        viewModel.getNavigateHome().observe(getViewLifecycleOwner(), go -> {
            if (!Boolean.TRUE.equals(go)) return;

            Navigation.findNavController(view).navigate(R.id.action_registerFragment_to_secondActivity);

            viewModel.navigationDone();
        });




    }

    private void showTopSnackbar(@NonNull View root, @NonNull String msg) {
        Snackbar sb = Snackbar.make(root, msg, Snackbar.LENGTH_LONG);
        sb.getView().setTranslationY(200);
        ((FrameLayout.LayoutParams) sb.getView().getLayoutParams()).gravity = Gravity.TOP;
        sb.show();
    }

}