package com.example.animevoid.data.remote.response;

import java.util.ArrayList;
import java.util.List;

public class TopAnimeResponse {
    public List<AnimeDto> data;

    public List<com.example.animevoid.model.Anime> toAnimeList(int limit) {
        List<com.example.animevoid.model.Anime> list = new ArrayList<>();

        if (data == null) return list;

        int count = Math.min(limit, data.size());
        for (int i = 0; i < count; i++) {
            list.add(data.get(i).toAnime());
        }
        return list;
    }
}