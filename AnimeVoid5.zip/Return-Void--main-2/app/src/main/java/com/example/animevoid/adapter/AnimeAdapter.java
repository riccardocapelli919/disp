package com.example.animevoid.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.animevoid.R;
import com.example.animevoid.model.Anime;

import java.util.ArrayList;
import java.util.List;

public class AnimeAdapter extends RecyclerView.Adapter<AnimeAdapter.AnimeViewHolder> {

    private final List<Anime> animeList = new ArrayList<>();

    public AnimeAdapter() {}

    public void setAnimeList(List<Anime> list) {
        animeList.clear();
        if (list != null) animeList.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public AnimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_anime_card, parent, false);
        return new AnimeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnimeViewHolder holder, int position) {
        Anime anime = animeList.get(position);

        holder.title.setText(anime.getTitle());

        // Placeholder subito, così lo vedi sempre
        holder.cover.setImageResource(R.drawable.card_placeholder);

        String url = anime.getImageUrl();
        if (url == null || url.trim().isEmpty()) return;

        Glide.with(holder.cover.getContext())
                .load(url)
                .placeholder(R.drawable.card_placeholder)
                .error(R.drawable.card_placeholder)
                .into(holder.cover);
    }

    @Override
    public int getItemCount() {
        return animeList.size();
    }

    static class AnimeViewHolder extends RecyclerView.ViewHolder {
        ImageView cover;
        TextView title;

        public AnimeViewHolder(@NonNull View itemView) {
            super(itemView);
            cover = itemView.findViewById(R.id.imgCover);
            title = itemView.findViewById(R.id.txtTitle);
        }
    }
}