package com.example.animevoid.model;

import java.io.Serializable;

public class Episode implements Serializable {

    private final int number;
    private final String title;

    public Episode(int number, String title) {
        this.number = number;
        this.title = title;
    }

    public int getNumber() {
        return number;
    }

    public String getTitle() {
        return title;
    }
}
