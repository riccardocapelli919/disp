package com.example.animevoid.data.repository;

import com.example.animevoid.data.remote.AnimeApiService;
import com.example.animevoid.data.remote.response.TopAnimeResponse;
import com.example.animevoid.model.Anime;
import com.example.animevoid.data.remote.response.AnimeDto;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AnimeRepositoryImpl implements AnimeRepository {

    private final AnimeApiService api;

    public AnimeRepositoryImpl() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.jikan.moe/v4/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api = retrofit.create(AnimeApiService.class);
    }

    @Override
    public void getTop5Anime(RepositoryCallback<List<Anime>> callback) {
        api.getTopAnime().enqueue(new Callback<TopAnimeResponse>() {
            @Override
            public void onResponse(Call<TopAnimeResponse> call, Response<TopAnimeResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onSuccess(response.body().toAnimeList(5));
                } else {
                    callback.onError(new Throwable("API error"));
                }
            }

            @Override
            public void onFailure(Call<TopAnimeResponse> call, Throwable t) {
                callback.onError(t);
            }
        });
    }

    @Override
    public void getActionAnime(RepositoryCallback<List<Anime>> callback) {
        getByGenre(1, callback); // Action
    }

    @Override
    public void getRomanceAnime(RepositoryCallback<List<Anime>> callback) {
        getByGenre(22, callback); // Romance
    }

    @Override
    public void getHorrorAnime(RepositoryCallback<List<Anime>> callback) {
        getByGenre(14, callback); // Horror
    }

    // ---------- helpers ----------

    private void getByGenre(int genreId,
                            RepositoryCallback<List<Anime>> callback) {

        api.getAnimeByGenre(genreId, 5)
                .enqueue(new Callback<TopAnimeResponse>() {
                    @Override
                    public void onResponse(Call<TopAnimeResponse> call,
                                           Response<TopAnimeResponse> response) {
                        callback.onSuccess(map(response.body(), 5));
                    }

                    @Override
                    public void onFailure(Call<TopAnimeResponse> call, Throwable t) {
                        callback.onError(t);
                    }
                });
    }

    private List<Anime> map(TopAnimeResponse body, int limit) {
        List<Anime> result = new ArrayList<>();

        if (body == null || body.data == null) return result;

        int count = Math.min(limit, body.data.size());

        for (int i = 0; i < count; i++) {
            AnimeDto dto = body.data.get(i);

            String imageUrl = "";
            if (dto.images != null && dto.images.jpg != null) {
                imageUrl = dto.images.jpg.imageUrl;
            }

            result.add(new Anime(
                    dto.malId,
                    dto.title,
                    imageUrl
            ));
        }

        return result;
    }
}