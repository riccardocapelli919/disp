package com.example.animevoid.ui.home.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animevoid.R;
import com.example.animevoid.adapter.AnimeAdapter;
import com.example.animevoid.adapter.Top5Adapter;
import com.example.animevoid.model.Anime;
import com.example.animevoid.ui.auth.AuthActivity;
import com.example.animevoid.ui.auth.fragment.AuthViewModel;
import com.example.animevoid.ui.home.ViewModels.HomeViewModel;
import com.example.animevoid.ui.streaming.AnimeDetailActivity;
import com.example.animevoid.utility.AnimeVoidText;
import com.google.android.material.snackbar.Snackbar;


public class HomeFragment extends Fragment {

    private static final int DEMON_SLAYER_S1_MAL_ID = 38000;

    private HomeViewModel viewModel;

    private Top5Adapter top5Adapter;
    private AnimeAdapter actionAdapter;
    private AnimeAdapter romanceAdapter;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // ===== TITLE =====
        TextView title = view.findViewById(R.id.appTitle);
        AnimeVoidText.apply(title);

        // ===== VIEWMODEL =====
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        // ===== SETUP LISTE =====
        setupTop5(view);
        setupAction(view);
        setupRomance(view);

        // ===== OBSERVE =====
        observeData();

        top5Adapter.setOnAnimeClickListener(this::openAnimeDetail);
        actionAdapter.setOnAnimeClickListener(this::openAnimeDetail);
        romanceAdapter.setOnAnimeClickListener(this::openAnimeDetail);

        // Demon Slayer
        Button btnDetails = view.findViewById(R.id.btnDetails);
        btnDetails.setOnClickListener(v -> openDemonSlayerSeason1());



        return view;
    }

    // ================= SETUP =================

    private void setupTop5(View view) {
        RecyclerView recycler = view.findViewById(R.id.recyclerTop5);
        recycler.setLayoutManager(
                new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        top5Adapter = new Top5Adapter();
        recycler.setAdapter(top5Adapter);
    }

    private void setupAction(View view) {
        RecyclerView recycler = view.findViewById(R.id.recyclerAction);
        recycler.setLayoutManager(
                new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        actionAdapter = new AnimeAdapter();
        recycler.setAdapter(actionAdapter);

    }

    private void setupRomance(View view) {
        RecyclerView recycler = view.findViewById(R.id.recyclerRomance);
        recycler.setLayoutManager(
                new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        romanceAdapter = new AnimeAdapter();
        recycler.setAdapter(romanceAdapter);
    }

    // ================= OBSERVE =================

    private void observeData() {
        viewModel.getTop5Anime().observe(getViewLifecycleOwner(), list -> {
            if (list != null) top5Adapter.setAnimeList(list);
        });

        viewModel.getActionAnime().observe(getViewLifecycleOwner(), list -> {
            if (list != null) actionAdapter.setAnimeList(list);
        });

        viewModel.getRomanceAnime().observe(getViewLifecycleOwner(), list -> {
            if (list != null) romanceAdapter.setAnimeList(list);
        });
    }

    private void openAnimeDetail(Anime anime) {
        Intent intent = new Intent(requireContext(), AnimeDetailActivity.class);
        intent.putExtra(AnimeDetailActivity.EXTRA_ANIME_ID, anime.getId());
        startActivity(intent);
    }
    private void openDemonSlayerSeason1() {
        Intent intent = new Intent(requireContext(), AnimeDetailActivity.class);
        intent.putExtra(AnimeDetailActivity.EXTRA_ANIME_ID, DEMON_SLAYER_S1_MAL_ID);
        startActivity(intent);
    }





}