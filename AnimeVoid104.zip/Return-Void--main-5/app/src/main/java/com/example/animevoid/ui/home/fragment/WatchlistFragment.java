package com.example.animevoid.ui.home.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animevoid.R;
import com.example.animevoid.adapter.WatchlistAdapter;
import com.example.animevoid.model.Anime;

import java.util.ArrayList;
import java.util.List;

public class WatchlistFragment extends Fragment {

    private RecyclerView recyclerView;
    private WatchlistAdapter adapter;

    public WatchlistFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_watchlist, container, false);

        recyclerView = view.findViewById(R.id.recyclerWatchlist);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        adapter = new WatchlistAdapter(requireContext());
        recyclerView.setAdapter(adapter);

        adapter.setAnimeList(
                com.example.animevoid.data.local.FavoritesManager.getAll()
        );

        return view;
    }
}
