package com.example.animevoid.ui.home.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animevoid.R;
import com.example.animevoid.adapter.AnimeAdapter;
import com.example.animevoid.model.Anime;
import com.example.animevoid.ui.home.ViewModels.SearchViewModel;
import com.example.animevoid.ui.streaming.AnimeDetailActivity;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

public class SearchFragment extends Fragment {

    private SearchViewModel viewModel;
    private AnimeAdapter adapter;

    private TextInputEditText etQuery;
    private ProgressBar progress;
    private TextView txtEmpty;

    private String currentQuery = "";

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        return view;
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etQuery = view.findViewById(R.id.etQuery);
        progress = view.findViewById(R.id.progressSearch);
        txtEmpty = view.findViewById(R.id.txtEmpty);

        setupRecycler(view);

        viewModel = new ViewModelProvider(this).get(SearchViewModel.class);

        observe(view);
        setupSearchActions();

        adapter.setOnAnimeClickListener(this::openAnimeDetail);

    }


    private void setupRecycler(View view) {
        RecyclerView recycler = view.findViewById(R.id.recyclerSearchResults);
        recycler.setLayoutManager(new GridLayoutManager(requireContext(), 3));
        recycler.setHasFixedSize(true);

        adapter = new AnimeAdapter();
        recycler.setAdapter(adapter);
    }

    private void setupSearchActions() {
        etQuery.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                String q = etQuery.getText() != null ? etQuery.getText().toString() : "";
                currentQuery = q.trim();
                viewModel.search(currentQuery);
                hideKeyboard(v);
                return true;
            }
            return false;
        });

        etQuery.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String q = s == null ? "" : s.toString().trim();
                currentQuery = q;
                if (q.isEmpty()) {
                    viewModel.clearResults();
                    txtEmpty.setVisibility(View.GONE);
                }
            }
        });
    }

    private void observe(View root) {
        viewModel.getResults().observe(getViewLifecycleOwner(), list -> {
            adapter.setAnimeList(list);
            updateEmptyState();
        });

        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            boolean loading = Boolean.TRUE.equals(isLoading);
            progress.setVisibility(loading ? View.VISIBLE : View.GONE);
            updateEmptyState();
        });

        viewModel.getMessageRes().observe(getViewLifecycleOwner(), resId -> {
            if (resId == null) return;
            Snackbar.make(root, getString(resId), Snackbar.LENGTH_LONG).show();
            viewModel.clearMessage();
        });
    }

    private void updateEmptyState() {
        boolean loading = Boolean.TRUE.equals(viewModel.getLoading().getValue());
        boolean hasQuery = currentQuery != null && !currentQuery.isEmpty();
        boolean isEmpty = adapter.getItemCount() == 0;

        if (!loading && hasQuery && isEmpty) {
            txtEmpty.setVisibility(View.VISIBLE);
        } else {
            txtEmpty.setVisibility(View.GONE);
        }
    }

    private void hideKeyboard(View view) {
        Context ctx = view.getContext();
        InputMethodManager imm = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private void openAnimeDetail(Anime anime) {
        Intent intent = new Intent(requireContext(), AnimeDetailActivity.class);
        intent.putExtra(AnimeDetailActivity.EXTRA_ANIME_ID, anime.getId());
        startActivity(intent);
    }

}
