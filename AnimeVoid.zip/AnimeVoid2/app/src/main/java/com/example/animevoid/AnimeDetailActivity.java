package com.example.animevoid;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.animevoid.R;

public class AnimeDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anime_detail);
    }
}