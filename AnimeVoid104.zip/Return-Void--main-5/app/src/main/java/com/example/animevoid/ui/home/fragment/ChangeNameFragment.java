package com.example.animevoid.ui.home.fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;

import com.example.animevoid.R;
import com.example.animevoid.ui.auth.fragment.AuthViewModel;
import com.google.android.material.snackbar.Snackbar;

public class ChangeNameFragment extends Fragment {

    private AuthViewModel authViewModel;

    public ChangeNameFragment() {
        // Required empty public constructor
    }
    public static ChangeNameFragment newInstance(String param1, String param2) {
        ChangeNameFragment fragment = new ChangeNameFragment();
        //Bundle args = new Bundle();
        //args.putString(ARG_PARAM1, param1);
        //args.putString(ARG_PARAM2, param2);
        //fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_change_name, container, false);

        EditText NuovoUsername = view.findViewById(R.id.edtNuovoNome);
        Button btnConfermaUsername = view.findViewById(R.id.btnConfermaNome);

        authViewModel = new ViewModelProvider(requireActivity()).get(AuthViewModel.class);

        btnConfermaUsername.setOnClickListener(v -> {
            String nuovoNome = NuovoUsername.getText() != null ? NuovoUsername.getText().toString() : "";
            authViewModel.cambioUsername(requireActivity(), nuovoNome);
        });

        authViewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            boolean loading = Boolean.TRUE.equals(isLoading);
            btnConfermaUsername.setEnabled(!loading);
            NuovoUsername.setEnabled(!loading);
        });

        authViewModel.getMessage().observe(getViewLifecycleOwner(), msg -> {
            if (msg != null) {
                showTopSnackbar(view, msg);
                authViewModel.clearMessage();
            }
        });

        authViewModel.getUsernameUpdated().observe(getViewLifecycleOwner(), updated -> {
            if (Boolean.TRUE.equals(updated)) {
                authViewModel.usernameUpdateDone();
                requireActivity().getOnBackPressedDispatcher().onBackPressed();
            }
        });

        return view;

}

    private void showTopSnackbar(@NonNull View root, @NonNull String msg) {
        Snackbar sb = Snackbar.make(root, msg, Snackbar.LENGTH_LONG);
        sb.getView().setTranslationY(200);
        ((FrameLayout.LayoutParams) sb.getView().getLayoutParams()).gravity = Gravity.TOP;
        sb.show();
    }
}