package com.example.animevoid.data.repository;

import com.example.animevoid.model.Anime;
import com.example.animevoid.model.AnimeDetail;
import com.example.animevoid.model.Episode;

import java.util.ArrayList;
import java.util.List;

public class FakeAnimeRepository implements AnimeRepository {

    @Override
    public void getTop5Anime(RepositoryCallback<List<Anime>> callback) {
        callback.onSuccess(new ArrayList<>(fakeTop5()));
    }

    @Override
    public void getActionAnime(RepositoryCallback<List<Anime>> callback) {
        callback.onSuccess(new ArrayList<>(fakeAction()));
    }

    @Override
    public void getRomanceAnime(RepositoryCallback<List<Anime>> callback) {
        callback.onSuccess(new ArrayList<>(fakeRomance()));
    }

    // ------------------------
    // FAKE DATA
    // ------------------------

    private List<Anime> fakeTop5() {
        List<Anime> list = new ArrayList<>();
        list.add(new Anime(1, "Attack on Titan", ""));
        list.add(new Anime(2, "Demon Slayer", ""));
        list.add(new Anime(3, "Jujutsu Kaisen", ""));
        list.add(new Anime(4, "One Piece", ""));
        list.add(new Anime(5, "Death Note", ""));
        return list;
    }

    private List<Anime> fakeAction() {
        List<Anime> list = new ArrayList<>();
        list.add(new Anime(10, "Naruto", ""));
        list.add(new Anime(11, "Bleach", ""));
        list.add(new Anime(12, "Dragon Ball Z", ""));
        return list;
    }

    private List<Anime> fakeRomance() {
        List<Anime> list = new ArrayList<>();
        list.add(new Anime(20, "Your Name", ""));
        list.add(new Anime(21, "Toradora", ""));
        list.add(new Anime(22, "Clannad", ""));
        return list;
    }

    @Override
    public void searchAnime(String query, RepositoryCallback<List<Anime>> callback) {
        String q = query == null ? "" : query.trim().toLowerCase();

        // Se l'utente non scrive nulla, ritorniamo lista vuota
        if (q.isEmpty()) {
            callback.onSuccess(new ArrayList<>());
            return;
        }

        // Dataset finto: uniamo tutte le liste fake che hai già
        List<Anime> all = new ArrayList<>();
        all.addAll(fakeTop5());
        all.addAll(fakeAction());
        all.addAll(fakeRomance());

        // Filtro per titolo
        List<Anime> result = new ArrayList<>();
        for (Anime a : all) {
            String title = a.getTitle();
            if (title != null && title.toLowerCase().contains(q)) {
                result.add(a);
            }
        }

        callback.onSuccess(result);
    }

    public void getAnimeDetails(int animeId, RepositoryCallback<AnimeDetail> callback) {
        return;
    }

    public void getAnimeEpisodes(int animeId, RepositoryCallback<List<Episode>> callback) {
        return;
    }

    private void fetchEpisodesPage(int animeId, int page, List<Episode> acc, RepositoryCallback<List<Episode>> callback) {
        return;
    }


}