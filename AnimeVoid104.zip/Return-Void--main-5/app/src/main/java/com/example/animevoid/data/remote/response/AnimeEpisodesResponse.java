package com.example.animevoid.data.remote.response;

import com.example.animevoid.model.Episode;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class AnimeEpisodesResponse {

    public Pagination pagination;
    public List<EpisodeDto> data;

    public List<Episode> toEpisodeList() {
        List<Episode> out = new ArrayList<>();
        if (data == null) return out;

        for (EpisodeDto dto : data) {
            if (dto != null) out.add(dto.toEpisode());
        }
        return out;
    }

    public static class Pagination {
        @SerializedName("has_next_page")
        public boolean hasNextPage;

        @SerializedName("current_page")
        public int currentPage;

        @SerializedName("last_visible_page")
        public int lastVisiblePage;
    }

    public static class EpisodeDto {
        @SerializedName("mal_id")
        public int malId;

        public String title;

        public Episode toEpisode() {
            return new Episode(malId, title != null ? title : "");
        }
    }
}
