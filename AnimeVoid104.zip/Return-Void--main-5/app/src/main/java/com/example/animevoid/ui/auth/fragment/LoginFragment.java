package com.example.animevoid.ui.auth.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.NavOptions;
import androidx.navigation.Navigation;

import com.example.animevoid.ui.home.MainActivity;
import com.example.animevoid.R;
import com.example.animevoid.data.auth.AuthManager;
import com.example.animevoid.utility.AnimeVoidText;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

public class LoginFragment extends Fragment {

    private AuthViewModel viewModel;

    public LoginFragment() {
        // Required empty public constructor
    }

    public static LoginFragment newInstance(String param1, String param2) {
        LoginFragment fragment = new LoginFragment();
        //Bundle args = new Bundle();
        //args.putString(ARG_PARAM1, param1);
        //args.putString(ARG_PARAM2, param2);
        //fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Cambio colore del titolo AnimeVoid e Login

        TextView title = view.findViewById(R.id.titleText);
        AnimeVoidText.apply(title);

        TextView title1 = view.findViewById(R.id.loginSubtitleText);
        AnimeVoidText.apply1(title1);

        MaterialTextView creaAccount = view.findViewById(R.id.crea_account_link);

        creaAccount.setOnClickListener(v -> {

            NavController navController = Navigation.findNavController(view);

            navController.navigate(R.id.action_loginFragment_to_registerFragment);

        });

        // Cambio colore Password dimenticata

        MaterialTextView passwordDimenticata = view.findViewById(R.id.forgotPasswordText);

        passwordDimenticata.setOnClickListener(v -> {

            NavController navController = Navigation.findNavController(view);

            navController.navigate(R.id.action_loginFragment_to_recuperoPassFragment);

        });

        // Auth

        viewModel = new ViewModelProvider(this).get(AuthViewModel.class);

        TextInputEditText inputEmail = view.findViewById(R.id.emailEditText);
        TextInputEditText inputPassword = view.findViewById(R.id.passwordEditText);

        MaterialButton btnLogin = view.findViewById(R.id.loginButton);
        MaterialButton btnGoogle = view.findViewById(R.id.googleLoginButton);

        // Login email e password normale (No Google)

        btnLogin.setOnClickListener(v -> {
            String email = inputEmail.getText() != null ? inputEmail.getText().toString() : "";
            String pass = inputPassword.getText() != null ? inputPassword.getText().toString() : "";
            viewModel.loginWithEmail(requireActivity(), email, pass);
        });

        // Login con Google

        btnGoogle.setOnClickListener(v -> viewModel.loginWithGoogle(requireActivity()));

        // Osservazione Stato (Disabilito i bottoni se è in loading)

        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            boolean enabled = isLoading == null || !isLoading;
            btnLogin.setEnabled(enabled);
            btnGoogle.setEnabled(enabled);
        });

        // Osservazione messaggi (errori per la maggioranza dei casi)

        viewModel.getMessage().observe(getViewLifecycleOwner(), msg -> {
            if (msg == null) return;
            showTopSnackbar(view, msg);
            viewModel.clearMessage();
        });

        // Navigazione

        viewModel.getNavigateHome().observe(getViewLifecycleOwner(), go -> {
            if (!Boolean.TRUE.equals(go)) return;

            Intent intent = new Intent(requireContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);

            viewModel.navigationDone();
        });



    }

    @Override
    public void onStart() {
        super.onStart();
        if (viewModel.hasUser()) {
            NavController navController = Navigation.findNavController(requireView());
            NavOptions navOptions = new NavOptions.Builder()
                    .setPopUpTo(R.id.loginFragment, true)
                    .build();
            navController.navigate(R.id.action_loginFragment_to_secondActivity, null, navOptions);
        }
    }

    private void showTopSnackbar(@NonNull View root, @NonNull String msg) {
        Snackbar sb = Snackbar.make(root, msg, Snackbar.LENGTH_LONG);
        sb.getView().setTranslationY(200);
        ((FrameLayout.LayoutParams) sb.getView().getLayoutParams()).gravity = Gravity.TOP;
        sb.show();
    }




}