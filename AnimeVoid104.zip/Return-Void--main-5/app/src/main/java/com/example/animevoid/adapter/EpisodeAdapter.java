package com.example.animevoid.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animevoid.R;
import com.example.animevoid.model.Episode;

import java.util.ArrayList;
import java.util.List;

public class EpisodeAdapter extends RecyclerView.Adapter<EpisodeAdapter.EpisodeVH> {

    public interface OnEpisodeClickListener {
        void onEpisodeClick(Episode episode);
    }

    private final List<Episode> episodes = new ArrayList<>();
    private OnEpisodeClickListener listener;

    public void setOnEpisodeClickListener(OnEpisodeClickListener listener) {
        this.listener = listener;
    }

    public void setEpisodes(List<Episode> list) {
        episodes.clear();
        if (list != null) episodes.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public EpisodeVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_episode, parent, false);
        return new EpisodeVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull EpisodeVH holder, int position) {
        Episode ep = episodes.get(position);

        holder.txtEp.setText("Ep " + ep.getNumber());
        holder.txtTitle.setText(ep.getTitle());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onEpisodeClick(ep);
        });
    }

    @Override
    public int getItemCount() {
        return episodes.size();
    }

    static class EpisodeVH extends RecyclerView.ViewHolder {
        TextView txtEp;
        TextView txtTitle;
        ImageView imgPlay;

        EpisodeVH(@NonNull View itemView) {
            super(itemView);
            txtEp = itemView.findViewById(R.id.txtEpisodeNumber);
            txtTitle = itemView.findViewById(R.id.txtEpisodeTitle);
            imgPlay = itemView.findViewById(R.id.imgPlay);
        }
    }
}
