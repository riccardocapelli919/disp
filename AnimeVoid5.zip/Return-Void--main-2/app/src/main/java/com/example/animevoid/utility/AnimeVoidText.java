package com.example.animevoid.utility;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.example.animevoid.R;

public class AnimeVoidText {

    public static void apply(TextView tv) {
        int c0 = ContextCompat.getColor(tv.getContext(), R.color.g0);
        int c1 = ContextCompat.getColor(tv.getContext(), R.color.g50);
        int c2 = ContextCompat.getColor(tv.getContext(), R.color.g100);

        tv.post(() -> {
            float w = tv.getWidth(); // larghezza della TextView
            if (w <= 0) return;

            LinearGradient shader = new LinearGradient(
                    0f, 0f, w, 0f,                       // sinistra -> destra
                    new int[]{c0, c1, c2},
                    new float[]{0f, 0.5f, 1f},
                    Shader.TileMode.CLAMP
            );

            tv.getPaint().setShader(shader);
            tv.invalidate();
        });
    }

    public static void apply1(TextView tv) {
        final int b0 = ContextCompat.getColor(tv.getContext(), R.color.login1);
        int b1 = ContextCompat.getColor(tv.getContext(), R.color.login2);

        // 70% alpha = 179 (0xB3)
        final int b1Alpha = (b1 & 0x00FFFFFF) | (0xB3 << 24);

        tv.post(() -> {
            float h = tv.getHeight();
            if (h <= 0) return;

            LinearGradient shader = new LinearGradient(
                    0f, 0f, 0f, h,                 // verticale: alto -> basso
                    new int[]{b0, b1Alpha},
                    new float[]{0f, 1f},
                    Shader.TileMode.CLAMP
            );

            tv.getPaint().setShader(shader);
            tv.invalidate();
        });
    }




}

