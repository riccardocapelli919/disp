package com.example.animevoid.ui.auth.fragment;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.animevoid.R;
import com.example.animevoid.data.auth.AuthManager;
import com.example.animevoid.utility.AnimeVoidText;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

public class RecuperoPassFragment extends Fragment {

    private AuthViewModel viewModel;

    public RecuperoPassFragment() {
        // Required empty public constructor
    }
    public static RecuperoPassFragment newInstance(String param1, String param2) {
        RecuperoPassFragment fragment = new RecuperoPassFragment();
        //Bundle args = new Bundle();
        //args.putString(ARG_PARAM1, param1);
        //args.putString(ARG_PARAM2, param2);
        //fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_recupero_pass, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(AuthViewModel.class);

        TextView title = view.findViewById(R.id.titleText);
        AnimeVoidText.apply(title);

        TextView title1 = view.findViewById(R.id.loginSubtitleText);
        AnimeVoidText.apply1(title1);

        MaterialButton btnReset = view.findViewById(R.id.ResetButton);

        TextInputEditText InputEmail = view.findViewById(R.id.emailEditText);

        TextInputEditText InputEmail1 = view.findViewById(R.id.emailConfirmText);

        // Logica per la modifica / recupero password

        btnReset.setOnClickListener(v -> {
            String email = InputEmail.getText() != null ? InputEmail.getText().toString() : "";
            String email2 = InputEmail1.getText() != null ? InputEmail1.getText().toString() : "";
            viewModel.resetPassword(requireActivity(), email, email2);
        });

        // Osservazione Stato (Disabilito i bottoni se è in loading)

        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            boolean enabled = isLoading == null || !isLoading;
            btnReset.setEnabled(enabled);
        });

        // Osservazione messaggi (errori per la maggioranza dei casi)

        viewModel.getMessage().observe(getViewLifecycleOwner(), msg -> {
            if (msg == null) return;
            showTopSnackbar(view, msg);
            viewModel.clearMessage();
        });




    }

    private void showTopSnackbar(@NonNull View root, @NonNull String msg) {
        Snackbar sb = Snackbar.make(root, msg, Snackbar.LENGTH_LONG);
        sb.getView().setTranslationY(200);
        ((FrameLayout.LayoutParams) sb.getView().getLayoutParams()).gravity = Gravity.TOP;
        sb.show();
    }


}