package com.example.animevoid.data.local;

import com.example.animevoid.model.Anime;

import java.util.ArrayList;
import java.util.List;

public class FavoritesManager {

    private static final List<Anime> favorites = new ArrayList<>();

    public static void add(Anime anime) {
        if (anime != null && !favorites.contains(anime)) {
            favorites.add(anime);
        }
    }

    public static void remove(Anime anime) {
        favorites.remove(anime);
    }

    public static boolean isFavorite(Anime anime) {
        return favorites.contains(anime);
    }

    public static List<Anime> getAll() {
        return new ArrayList<>(favorites);
    }
}
