package com.example.animevoid.data.repository;

public interface RepositoryCallback<T> {
    void onSuccess(T data);
    void onError(Throwable t);
}