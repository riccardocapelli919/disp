package com.example.animevoid.ui.home;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animevoid.R;
import com.example.animevoid.adapter.AnimeAdapter;
import com.example.animevoid.adapter.Top5Adapter;

public class HomeActivity extends AppCompatActivity {

    private HomeViewModel viewModel;

    private Top5Adapter top5Adapter;
    private AnimeAdapter actionAdapter;
    private AnimeAdapter romanceAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        setupTop5();
        setupAction();
        setupRomance();

        observeData();
    }

    // ================= SETUP =================

    private void setupTop5() {
        RecyclerView recycler = findViewById(R.id.recyclerTop5);
        recycler.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        top5Adapter = new Top5Adapter();
        recycler.setAdapter(top5Adapter);
    }

    private void setupAction() {
        RecyclerView recycler = findViewById(R.id.recyclerAction);
        recycler.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        actionAdapter = new AnimeAdapter();
        recycler.setAdapter(actionAdapter);
    }

    private void setupRomance() {
        RecyclerView recycler = findViewById(R.id.recyclerRomance);
        recycler.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        romanceAdapter = new AnimeAdapter();
        recycler.setAdapter(romanceAdapter);
    }


    // ================= OBSERVE =================

    private void observeData() {
        viewModel.getTop5Anime().observe(this, list -> {
            if (list != null) top5Adapter.setAnimeList(list);
        });

        viewModel.getActionAnime().observe(this, list -> {
            if (list != null) actionAdapter.setAnimeList(list);
        });

        viewModel.getRomanceAnime().observe(this, list -> {
            if (list != null) romanceAdapter.setAnimeList(list);
        });

    }
}