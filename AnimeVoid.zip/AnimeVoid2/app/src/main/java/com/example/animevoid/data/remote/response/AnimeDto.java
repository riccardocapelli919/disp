package com.example.animevoid.data.remote.response;

import com.example.animevoid.model.Anime;
import com.google.gson.annotations.SerializedName;

public class AnimeDto {

    @SerializedName("mal_id")
    public int malId;

    @SerializedName("title")
    public String title;

    @SerializedName("images")
    public Images images;

    public Anime toAnime() {
        String imageUrl = "";

        if (images != null && images.jpg != null) {
            imageUrl = images.jpg.imageUrl;
        }

        return new Anime(
                malId,
                title,
                imageUrl
        );
    }

    // --- inner classes ---
    public static class Images {
        @SerializedName("jpg")
        public Jpg jpg;
    }

    public static class Jpg {
        @SerializedName("image_url")
        public String imageUrl;
    }
}