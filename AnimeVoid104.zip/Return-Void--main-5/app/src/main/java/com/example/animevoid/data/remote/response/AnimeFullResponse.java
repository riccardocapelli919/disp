package com.example.animevoid.data.remote.response;

import com.example.animevoid.model.AnimeDetail;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class AnimeFullResponse {

    public Data data;

    public AnimeDetail toAnimeDetail() {
        if (data == null) return null;
        return data.toAnimeDetail();
    }

    public static class Data {
        @SerializedName("mal_id")
        public int malId;

        public String title;

        @SerializedName("synopsis")
        public String synopsis;

        public Integer episodes;

        public Trailer trailer;

        public List<Genre> genres;

        public AnimeDetail toAnimeDetail() {
            int total = (episodes != null) ? episodes : 0;

            List<String> genreNames = new ArrayList<>();
            if (genres != null) {
                for (Genre g : genres) {
                    if (g != null && g.name != null && !g.name.trim().isEmpty()) {
                        genreNames.add(g.name.trim());
                    }
                }
            }

            String embed = null;
            if (trailer != null) {
                if (trailer.embedUrl != null && !trailer.embedUrl.trim().isEmpty()) {
                    embed = trailer.embedUrl.trim();
                } else if (trailer.youtubeId != null && !trailer.youtubeId.trim().isEmpty()) {
                    embed = "https://www.youtube.com/embed/" + trailer.youtubeId.trim() + "?autoplay=1";
                }
            }

            String cleanSynopsis = synopsis != null ? synopsis : "";
            cleanSynopsis = cleanSynopsis.replaceAll("\\s*\\[Written by MAL Rewrite\\]\\s*", "");
            cleanSynopsis = cleanSynopsis.trim();

            return new AnimeDetail(
                    malId,
                    title != null ? title : "",
                    cleanSynopsis,
                    total,
                    genreNames,
                    embed
            );
        }
    }

    public static class Trailer {
        @SerializedName("embed_url")
        public String embedUrl;

        @SerializedName("youtube_id")
        public String youtubeId;

        public String url;
    }

    public static class Genre {
        public String name;
    }
}
