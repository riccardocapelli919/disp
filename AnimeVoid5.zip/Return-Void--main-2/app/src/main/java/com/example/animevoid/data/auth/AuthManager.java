package com.example.animevoid.data.auth;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.credentials.ClearCredentialStateRequest;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.ClearCredentialException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.NoCredentialException;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.FirebaseTooManyRequestsException;

import com.example.animevoid.R;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

public final class AuthManager {

    // Singleton
    private static final class Holder {
        private static final AuthManager INSTANCE = new AuthManager();
    }

    public static AuthManager getInstance() {
        return Holder.INSTANCE;
    }

    private FirebaseAuth auth;
    private CredentialManager credentialManager;
    private Context appContext;

    // Impedire che altri creino nuove istanze
    private AuthManager() { }

    // Chiama una sola volta (Fatto su MyApp)
    public void init(@NonNull Context context) {
        appContext = context.getApplicationContext();
        auth = FirebaseAuth.getInstance();
        credentialManager = CredentialManager.create(appContext);
    }

    // Callback standard per login/registrazione
    public interface AuthCallback {
        void onSuccess(@NonNull FirebaseUser user);
        void onError(@NonNull String message, @Nullable Exception exception);
    }

    // Callback per operazioni "void" (reset password, logout)
    public interface ActionCallback {
        void onSuccess();
        void onError(@NonNull String message, @Nullable Exception exception);
    }


    // Stato utente
    public boolean hasUser() {
        return auth != null && auth.getCurrentUser() != null;
    }

    @Nullable
    public FirebaseUser getCurrentUser() {
        return auth != null ? auth.getCurrentUser() : null;
    }

    public void signOut(@NonNull Activity activity, @NonNull ActionCallback callback) {
        if (auth == null || credentialManager == null) {
            callback.onError("AuthManager non inizializzato. Chiama init(context).", null);
            return;
        }

        // 1) Firebase sign out
        auth.signOut();

        // 2) Credential Manager: pulire lo stato credenziali
        ClearCredentialStateRequest clearRequest = new ClearCredentialStateRequest();
        credentialManager.clearCredentialStateAsync(
                clearRequest,
                null,
                activity.getMainExecutor(),
                new CredentialManagerCallback<Void, ClearCredentialException>() {
                    @Override
                    public void onResult(@NonNull Void result) {
                        callback.onSuccess();
                    }

                    @Override
                    public void onError(@NonNull ClearCredentialException e) {
                        // Sei comunque disconnesso da Firebase, quindi spesso puoi trattarlo come "soft error"
                        callback.onError("Logout eseguito, ma non sono riuscito a pulire lo stato credenziali.", e);
                    }
                }
        );
    }


    // Email + password
    public void signInWithEmail(
            @NonNull Activity activity,
            @NonNull String email,
            @NonNull String password,
            @NonNull AuthCallback callback
    ) {
        if (auth == null) {
            callback.onError("AuthManager non inizializzato. Chiama init(context).", null);
            return;
        }

        String e = email.trim();
        String p = password;

        if (e.isEmpty() || p.isEmpty()) {
            callback.onError("Inserisci email e password.", null);
            return;
        }
        if (!isEmailValid(e)) {
            callback.onError("Email non valida.", null);
            return;
        }

        try {
            auth.signInWithEmailAndPassword(e, p)
                    .addOnCompleteListener(activity, task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser user = auth.getCurrentUser();
                            if (user != null) callback.onSuccess(user);
                            else callback.onError("Login riuscito ma utente nullo (caso raro).", null);
                        } else {
                            Exception ex = task.getException();
                            Log.e("AuthManager", "Firebase auth failed (signInWithEmail)", ex);
                            callback.onError(mapAuthError(ex), ex);
                        }
                    });
        } catch (IllegalArgumentException ex) {
            callback.onError("Inserisci email e password.", ex);
        }
    }

    public void signUpWithEmail(
            @NonNull Activity activity,
            @NonNull String username,
            @NonNull String email,
            @NonNull String password,
            @NonNull AuthCallback callback
    ) {
        if (auth == null) {
            callback.onError("AuthManager non inizializzato. Chiama init(context).", null);
            return;
        }

        String cleanEmail = email.trim();
        String cleanPassword = password;
        String cleanUsername = username.trim();

        if (cleanUsername.isEmpty()) {
            callback.onError("Inserisci uno username valido.", null);
            return;
        }

        if (cleanEmail.isEmpty() || cleanPassword.isEmpty()) {
            callback.onError("Inserisci email e password.", null);
            return;
        }

        if (!isEmailValid(cleanEmail)) {
            callback.onError("Email non valida.", null);
            return;
        }

        if (!isPasswordValid(cleanPassword)) {
            callback.onError("Password non valida (minimo 6 caratteri)", null);
            return;
        }

        auth.createUserWithEmailAndPassword(cleanEmail, cleanPassword)
                .addOnCompleteListener(activity, task -> {
                    if (!task.isSuccessful()) {
                        Exception ex = task.getException();
                        Log.e("AuthManager", "Firebase auth failed (signUpWithEmail)", ex);
                        callback.onError(mapAuthError(ex), ex);
                        return;
                    }

                    FirebaseUser user = auth.getCurrentUser();
                    if (user == null) {
                        callback.onError("Registrazione riuscita ma utente nullo (caso raro).", null);
                        return;
                    }

                    // Salviamo lo username nel displayName del profilo Firebase
                    UserProfileChangeRequest updates = new UserProfileChangeRequest.Builder()
                            .setDisplayName(cleanUsername)
                            .build();

                    user.updateProfile(updates)
                            .addOnCompleteListener(activity, profileTask -> {
                                if (profileTask.isSuccessful()) {
                                    callback.onSuccess(user);
                                } else {
                                    callback.onError("Account creato, ma non riesco a salvare lo username.", profileTask.getException());
                                }
                            });
                });
    }

    public void sendPasswordResetEmail(
            @NonNull Activity activity,
            @NonNull String email,
            @NonNull ActionCallback callback
    ) {
        if (auth == null) {
            callback.onError("AuthManager non inizializzato. Chiama init(context).", null);
            return;
        }

        if (email.isEmpty()) {
            callback.onError("Inserisci email.", null);
            return;
        }

        if (!isEmailValid(email)) {
            callback.onError("Email non valida.", null);
            return;
        }


        auth.sendPasswordResetEmail(email.trim())
                .addOnCompleteListener(activity, task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess();
                    }
                    else {
                        Exception ex = task.getException();
                        Log.e("AuthManager", "Firebase auth failed (sendPasswordResetEmail)", ex);
                        callback.onError(mapAuthError(ex), ex);
                    };
                });
    }


    // Google Sign-In (Credential Manager)
    public void signInWithGoogle(@NonNull Activity activity, @NonNull AuthCallback callback) {
        // 1) Provo con soli account già autorizzati
        signInWithGoogleInternal(activity, true, new AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                callback.onSuccess(user);
            }

            @Override
            public void onError(@NonNull String message, @Nullable Exception exception) {
                // 2) Se non c'è nessun account "autorizzato", riprovo mostrando tutti gli account
                if (exception instanceof NoCredentialException) {
                    signInWithGoogleInternal(activity, false, callback);
                } else {
                    callback.onError(message, exception);
                }
            }
        });
    }

    private void signInWithGoogleInternal(
            @NonNull Activity activity,
            boolean onlyAuthorizedAccounts,
            @NonNull AuthCallback callback
    ) {
        if (auth == null || credentialManager == null) {
            callback.onError("AuthManager non inizializzato. Chiama init(context).", null);
            return;
        }

        GetGoogleIdOption googleIdOption = new GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(onlyAuthorizedAccounts)
                .setServerClientId(activity.getString(R.string.client_id))
                .build();


        GetCredentialRequest request = new GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build();

        credentialManager.getCredentialAsync(
                activity,
                request,
                null,
                activity.getMainExecutor(),
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override
                    public void onResult(@NonNull GetCredentialResponse result) {
                        handleGoogleCredential(activity, result.getCredential(), callback);
                    }

                    @Override
                    public void onError(@NonNull GetCredentialException e) {

                        Log.e("AuthManager", "getCredentialAsync failed: "
                                + e.getClass().getSimpleName() + " | " + e.getMessage(), e);

                        if (e instanceof androidx.credentials.exceptions.NoCredentialException) {
                            callback.onError("Nessun account Google disponibile sul dispositivo. Aggiungi un account Google o usa un emulatore con Google Play.", e);
                            return;
                        }

                        if (e instanceof GetCredentialCancellationException) {
                            callback.onError("Accesso Google annullato.", e);
                        } else {
                            callback.onError("Impossibile completare accesso Google.", e);
                        }
                    }
                }
        );
    }

    private void handleGoogleCredential(
            @NonNull Activity activity,
            @NonNull Credential credential,
            @NonNull AuthCallback callback
    ) {
        if (!(credential instanceof CustomCredential)) {
            callback.onError("Credenziale non supportata.", null);
            return;
        }

        CustomCredential customCredential = (CustomCredential) credential;

        if (!GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(customCredential.getType())) {
            callback.onError("Credenziale non è Google ID Token.", null);
            return;
        }

        Bundle data = customCredential.getData();
        GoogleIdTokenCredential googleIdTokenCredential = GoogleIdTokenCredential.createFrom(data);
        String idToken = googleIdTokenCredential.getIdToken();

        AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(idToken, null);

        auth.signInWithCredential(firebaseCredential)
                .addOnCompleteListener(activity, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = auth.getCurrentUser();
                        if (user == null) {
                            callback.onError("Login Google riuscito ma utente nullo (caso raro).", null);
                            return;
                        }

                        String username = buildUsernameFromGoogleDisplayName(user.getDisplayName());

                        // Fallback se displayName non c'è
                        if (username == null) {
                            String email = user.getEmail();
                            if (email != null && email.contains("@")) {
                                username = email.substring(0, email.indexOf("@"));
                            } else {
                                username = "User_" + user.getUid().substring(0, 6);
                            }
                        }

                        UserProfileChangeRequest updates = new UserProfileChangeRequest.Builder()
                                .setDisplayName(username)
                                .build();

                        user.updateProfile(updates)
                                .addOnCompleteListener(activity, profileTask -> {
                                    if (profileTask.isSuccessful()) {
                                        callback.onSuccess(user);
                                    } else {
                                        callback.onError("Login Google OK, ma non riesco a salvare lo username.", profileTask.getException());
                                    }
                                });

                    } else {
                        Exception ex = task.getException();
                        Log.e("AuthManager", "Firebase auth failed (signInWithGoogle -> signInWithCredential)", ex);
                        callback.onError(mapAuthError(ex), ex);
                    }
                });
    }

    @Nullable
    private String buildUsernameFromGoogleDisplayName(@Nullable String displayName) {
        if (displayName == null) return null;

        String cleaned = displayName.trim().replaceAll("\\s+", " ");
        if (cleaned.isEmpty()) return null;

        String[] parts = cleaned.split(" ");
        if (parts.length >= 2) {
            String firstName = parts[0];
            String lastName = parts[parts.length - 1];
            String username = firstName + "_" + lastName;

            // Pulizia base: rimuove caratteri strani lasciando lettere, numeri e underscore
            username = username.replaceAll("[^\\p{L}\\p{N}_]", "");
            return username.isEmpty() ? null : username;
        } else {
            String username = parts[0].replaceAll("[^\\p{L}\\p{N}_]", "");
            return username.isEmpty() ? null : username;
        }
    }


    // Helper validazione
    public boolean isEmailValid(@Nullable String email) {
        return email != null && Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches();
    }

    public boolean isPasswordValid(@Nullable String password) {
        // Firebase accetta minimo 6
        return password != null && password.length() >= 6;
    }


    // Mappatura errori
    private String mapAuthError(@Nullable Exception e) {
        if (e == null) return "Operazione fallita. Riprova.";

        if (e instanceof FirebaseAuthException) {
            String code = ((FirebaseAuthException) e).getErrorCode();

            if ("ERROR_OPERATION_NOT_ALLOWED".equals(code)) {
                return "Metodo di accesso non abilitato in Firebase Console (Google o Email/Password).";
            }
            if ("ERROR_INVALID_API_KEY".equals(code) || "ERROR_APP_NOT_AUTHORIZED".equals(code)) {
                return "Configurazione Firebase non valida per questa app. Controlla google-services.json, package name e API key.";
            }
            if ("ERROR_TOO_MANY_REQUESTS".equals(code)) {
                return "Troppe richieste. Riprova più tardi.";
            }

            // fallback informativo
            return e.getLocalizedMessage() != null ? e.getLocalizedMessage() : "Operazione fallita. Riprova.";
        }

        if (e instanceof FirebaseAuthInvalidUserException) return "Utente non trovato. Controlla email e riprova.";
        if (e instanceof FirebaseAuthInvalidCredentialsException) return "Credenziali non valide. Controlla email e password.";
        if (e instanceof FirebaseAuthUserCollisionException) return "Esiste già un account con questa email.";
        if (e instanceof FirebaseNetworkException) return "Problema di rete. Controlla la connessione e riprova.";
        if (e instanceof FirebaseTooManyRequestsException) return "Troppe richieste. Riprova più tardi.";

        return e.getLocalizedMessage() != null ? e.getLocalizedMessage() : "Operazione fallita. Riprova.";
    }

}


