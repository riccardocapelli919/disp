package com.example.animevoid.data.remote.response;

import com.example.animevoid.model.Anime;
import com.google.gson.annotations.SerializedName;

public class AnimeDto {

    @SerializedName("mal_id")
    public int malId;

    public String title;

    public Images images;

    public Anime toAnime() {
        String imageUrl = null;

        if (images != null && images.jpg != null) {
            imageUrl = images.jpg.imageUrl;        }

        return new Anime(
                malId,
                title,
                imageUrl
        );
    }

    public static class Images {
        public Jpg jpg;
    }

    public static class Jpg {
        @SerializedName("image_url")
        public String imageUrl;

        @SerializedName("large_image_url")
        public String largeImageUrl;
    }
}