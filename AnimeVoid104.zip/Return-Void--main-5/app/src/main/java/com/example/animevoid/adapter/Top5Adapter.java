package com.example.animevoid.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.animevoid.R;
import com.example.animevoid.model.Anime;

import java.util.ArrayList;
import java.util.List;

public class Top5Adapter extends RecyclerView.Adapter<Top5Adapter.Top5ViewHolder> {

    private final List<Anime> animeList = new ArrayList<>();

    private OnAnimeClickListener listener;

    public Top5Adapter() {
    }

    public void setOnAnimeClickListener(OnAnimeClickListener listener) {
        this.listener = listener;
    }

    public void setAnimeList(List<Anime> list) {
        animeList.clear();
        if (list != null) {
            animeList.addAll(list);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Top5ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_top5_anime, parent, false);
        return new Top5ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Top5ViewHolder holder, int position) {
        Anime anime = animeList.get(position);

        holder.rank.setText(String.valueOf(position + 1));

        Glide.with(holder.itemView.getContext())
                .load(anime.getImageUrl())
                .placeholder(R.drawable.card_placeholder)
                .into(holder.cover);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onAnimeClick(anime);
        });
    }
    @Override
    public int getItemCount() {
        return animeList.size();
    }

    static class Top5ViewHolder extends RecyclerView.ViewHolder {
        TextView rank;
        ImageView cover;

        public Top5ViewHolder(@NonNull View itemView) {
            super(itemView);
            rank = itemView.findViewById(R.id.txtRank);
            cover = itemView.findViewById(R.id.imgCover);
        }
    }
}