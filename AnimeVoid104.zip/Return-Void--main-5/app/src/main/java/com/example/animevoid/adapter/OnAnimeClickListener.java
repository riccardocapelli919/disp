package com.example.animevoid.adapter;

import com.example.animevoid.model.Anime;

public interface OnAnimeClickListener {
    void onAnimeClick(Anime anime);
}
