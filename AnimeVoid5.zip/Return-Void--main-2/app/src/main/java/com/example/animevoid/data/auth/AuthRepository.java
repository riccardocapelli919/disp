package com.example.animevoid.data.auth;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.animevoid.data.auth.AuthManager;
import com.google.firebase.auth.FirebaseUser;

public class AuthRepository {

    public interface AuthCallback {
        void onSuccess(@NonNull FirebaseUser user);
        void onError(@NonNull String message, @Nullable Exception exception);
    }

    public interface SimpleCallback {
        void onSuccess();
        void onError(@NonNull String message, @Nullable Exception exception);
    }

    private final AuthManager authManager;

    public AuthRepository(@NonNull AuthManager authManager) {
        this.authManager = authManager;
    }

    public boolean hasUser() {
        return authManager.hasUser();
    }

    @Nullable
    public FirebaseUser getCurrentUser() {
        return authManager.getCurrentUser();
    }

    public void loginWithEmail(@NonNull Activity activity,
                               @NonNull String email,
                               @NonNull String password,
                               @NonNull AuthCallback callback) {
        authManager.signInWithEmail(activity, email, password, new AuthManager.AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                callback.onSuccess(user);
            }

            @Override
            public void onError(@NonNull String message, @Nullable Exception exception) {
                callback.onError(message, exception);
            }
        });
    }

    public void registerWithEmail(@NonNull Activity activity,
                                  @NonNull String username,
                                  @NonNull String email,
                                  @NonNull String password,
                                  @NonNull AuthCallback callback) {
        authManager.signUpWithEmail(activity, username, email, password, new AuthManager.AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                callback.onSuccess(user);
            }

            @Override
            public void onError(@NonNull String message, @Nullable Exception exception) {
                callback.onError(message, exception);
            }
        });
    }

    public void resetPassword(@NonNull Activity activity,
                              @NonNull String email,
                              @NonNull SimpleCallback callback) {
        authManager.sendPasswordResetEmail(activity, email, new AuthManager.ActionCallback() {
            @Override
            public void onSuccess() {
                callback.onSuccess();
            }

            @Override
            public void onError(@NonNull String message, @Nullable Exception exception) {
                callback.onError(message, exception);
            }
        });
    }

    public void loginWithGoogle(@NonNull Activity activity,
                                @NonNull AuthCallback callback) {
        authManager.signInWithGoogle(activity, new AuthManager.AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                callback.onSuccess(user);
            }

            @Override
            public void onError(@NonNull String message, @Nullable Exception exception) {
                callback.onError(message, exception);
            }
        });
    }

    public void signOut(@NonNull Activity activity,
                        @NonNull SimpleCallback callback) {
        authManager.signOut(activity, new AuthManager.ActionCallback() {
            @Override
            public void onSuccess() {
                callback.onSuccess();
            }

            @Override
            public void onError(@NonNull String message, @Nullable Exception exception) {
                callback.onError(message, exception);
            }
        });
    }
}
