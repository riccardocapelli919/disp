package com.example.animevoid.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AnimeDetail implements Serializable {

    private final int id;
    private final String title;
    private final String synopsis;
    private final int totalEpisodes;
    private final List<String> genres;
    private final String trailerEmbedUrl;

    public AnimeDetail(int id, String title, String synopsis, int totalEpisodes, List<String> genres, String trailerEmbedUrl) {
        this.id = id;
        this.title = title;
        this.synopsis = synopsis;
        this.totalEpisodes = totalEpisodes;
        this.genres = (genres == null) ? new ArrayList<>() : genres;
        this.trailerEmbedUrl = trailerEmbedUrl;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public int getTotalEpisodes() {
        return totalEpisodes;
    }

    public List<String> getGenres() {
        return genres;
    }

    public String getTrailerEmbedUrl() {
        return trailerEmbedUrl;
    }
}
