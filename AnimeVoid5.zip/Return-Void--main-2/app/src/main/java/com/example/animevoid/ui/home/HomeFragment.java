package com.example.animevoid.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animevoid.R;
import com.example.animevoid.adapter.AnimeAdapter;
import com.example.animevoid.adapter.Top5Adapter;
import com.example.animevoid.data.auth.AuthManager;
import com.example.animevoid.ui.auth.AuthActivity;
import com.example.animevoid.utility.AnimeVoidText;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;

public class HomeFragment extends Fragment {

    private HomeViewModel viewModel;

    private Top5Adapter top5Adapter;
    private AnimeAdapter actionAdapter;
    private AnimeAdapter romanceAdapter;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // ===== TITLE =====
        TextView title = view.findViewById(R.id.appTitle);
        AnimeVoidText.apply(title);

        // ===== VIEWMODEL =====
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        // ===== SETUP LISTE =====
        setupTop5(view);
        setupAction(view);
        setupRomance(view);

        // ===== OBSERVE =====
        observeData();

        // ===== LOGOUT =====
        setupLogout(view);

        return view;
    }

    // ================= SETUP =================

    private void setupTop5(View view) {
        RecyclerView recycler = view.findViewById(R.id.recyclerTop5);
        recycler.setLayoutManager(
                new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        top5Adapter = new Top5Adapter();
        recycler.setAdapter(top5Adapter);
    }

    private void setupAction(View view) {
        RecyclerView recycler = view.findViewById(R.id.recyclerAction);
        recycler.setLayoutManager(
                new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        actionAdapter = new AnimeAdapter();
        recycler.setAdapter(actionAdapter);
    }

    private void setupRomance(View view) {
        RecyclerView recycler = view.findViewById(R.id.recyclerRomance);
        recycler.setLayoutManager(
                new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        romanceAdapter = new AnimeAdapter();
        recycler.setAdapter(romanceAdapter);
    }

    // ================= OBSERVE =================

    private void observeData() {
        viewModel.getTop5Anime().observe(getViewLifecycleOwner(), list -> {
            if (list != null) top5Adapter.setAnimeList(list);
        });

        viewModel.getActionAnime().observe(getViewLifecycleOwner(), list -> {
            if (list != null) actionAdapter.setAnimeList(list);
        });

        viewModel.getRomanceAnime().observe(getViewLifecycleOwner(), list -> {
            if (list != null) romanceAdapter.setAnimeList(list);
        });
    }

    // ================= LOGOUT =================

    private void setupLogout(View view) {
        AuthManager auth = AuthManager.getInstance();

        BottomNavigationView bottomNav = view.findViewById(R.id.bottom_nav);
        MenuItem logout = bottomNav.getMenu().findItem(R.id.nav_profile);

        bottomNav.setOnItemSelectedListener(item -> {

            if (item.getItemId() == logout.getItemId()) {

                auth.signOut(requireActivity(), new AuthManager.ActionCallback() {
                    @Override
                    public void onSuccess() {
                        Intent i = new Intent(requireContext(), AuthActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        requireActivity().finish();
                    }

                    @Override
                    public void onError(@NonNull String msg, Exception e) {
                        Snackbar.make(view, msg, Snackbar.LENGTH_LONG).show();

                        Intent i = new Intent(requireContext(), AuthActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        requireActivity().finish();
                    }
                });
                return true;
            }
            return false;
        });
    }
}