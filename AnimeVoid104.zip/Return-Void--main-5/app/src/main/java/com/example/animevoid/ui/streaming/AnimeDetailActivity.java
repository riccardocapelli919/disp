package com.example.animevoid.ui.streaming;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animevoid.R;
import com.example.animevoid.adapter.EpisodeAdapter;
import com.example.animevoid.model.AnimeDetail;
import com.example.animevoid.model.Episode;
import com.example.animevoid.ui.streaming.ViewModels.AnimeDetailViewModel;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

import java.util.ArrayList;
import java.util.List;

public class AnimeDetailActivity extends AppCompatActivity {

    public static final String EXTRA_ANIME_ID = "extra_anime_id";

    private static final String STATE_FAVORITE = "state_favorite";

    private View rootView;

    private AnimeDetailViewModel viewModel;

    private Toolbar toolbarDetail;
    private NestedScrollView scrollContent;

    private FrameLayout playerContainer;
    private FrameLayout fullScreenViewContainer;
    private ImageButton btnFullscreen;

    private boolean isFullscreen = false;
    private ViewGroup originalPlayerParent;
    private int originalPlayerIndex = -1;
    private ViewGroup.LayoutParams originalPlayerLayoutParams;
    private Drawable originalPlayerBackground;

    private YouTubePlayerView youtubePlayerView;
    private YouTubePlayer youTubePlayer;
    private String pendingVideoId;

    private TextView txtPlayerHint;
    private Button btnOpenInYouTube;

    private RecyclerView rvEpisodes;
    private EpisodeAdapter episodeAdapter;

    private TextView txtAnimeTitle;
    private TextView txtTotalEpisodes;
    private TextView txtGenres;
    private TextView txtSynopsis;

    private TextView btnToggleEpisodes;
    private boolean episodesVisible = true;

    private ImageButton btnFavorite;
    private boolean isFavorite = false;

    private ProgressBar progressDetail;
    private TextView txtError;

    private AnimeDetail currentDetail;
    private String currentVideoId;

    private List<Episode> lastEpisodesFromApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anime_detail);
        rootView = findViewById(android.R.id.content);

        int animeId = getIntent().getIntExtra(EXTRA_ANIME_ID, -1);
        if (animeId <= 0) {
            finish();
            return;
        }

        toolbarDetail = findViewById(R.id.toolbarDetail);
        setSupportActionBar(toolbarDetail);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("");
        }

        scrollContent = findViewById(R.id.scrollContent);

        playerContainer = findViewById(R.id.playerContainer);
        fullScreenViewContainer = findViewById(R.id.fullScreenViewContainer);
        btnFullscreen = findViewById(R.id.btnFullscreen);

        if (playerContainer != null) {
            originalPlayerBackground = playerContainer.getBackground();
        }

        youtubePlayerView = findViewById(R.id.youtubePlayerView);
        txtPlayerHint = findViewById(R.id.txtPlayerHint);
        btnOpenInYouTube = findViewById(R.id.btnOpenInYouTube);

        rvEpisodes = findViewById(R.id.rvEpisodes);
        btnToggleEpisodes = findViewById(R.id.btnToggleEpisodes);

        txtAnimeTitle = findViewById(R.id.txtAnimeTitle);
        btnFavorite = findViewById(R.id.btnFavorite);

        txtTotalEpisodes = findViewById(R.id.txtTotalEpisodes);
        txtGenres = findViewById(R.id.txtGenres);
        txtSynopsis = findViewById(R.id.txtSynopsis);
        progressDetail = findViewById(R.id.progressDetail);
        txtError = findViewById(R.id.txtError);

        if (savedInstanceState != null) {
            isFavorite = savedInstanceState.getBoolean(STATE_FAVORITE, false);
        }

        setupFavorite();
        setupYouTubePlayer();
        setupEpisodesList();
        setupEpisodesToggle();
        setupOpenInYouTube();
        setupFullscreen();

        viewModel = new ViewModelProvider(this).get(AnimeDetailViewModel.class);
        observeVm();
        viewModel.load(animeId);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putBoolean(STATE_FAVORITE, isFavorite);
        super.onSaveInstanceState(outState);
    }

    private void setupFavorite() {
        if (btnFavorite == null) return;

        updateFavoriteUi();

        btnFavorite.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            updateFavoriteUi();
        });
    }

    private void updateFavoriteUi() {
        if (btnFavorite == null) return;

        if (isFavorite) {
            btnFavorite.setImageResource(R.drawable.ic_favorite_filled);
            btnFavorite.setColorFilter(ContextCompat.getColor(this, android.R.color.holo_red_light));
        } else {
            btnFavorite.setImageResource(R.drawable.ic_favorite_border);
            btnFavorite.setColorFilter(ContextCompat.getColor(this, R.color.text_white));
        }
    }

    private void setupYouTubePlayer() {
        getLifecycle().addObserver(youtubePlayerView);

        showPlayerMessage("Caricamento trailer...");

        youtubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer player) {
                youTubePlayer = player;

                if (pendingVideoId != null) {
                    setPlayerAvailable();
                    youTubePlayer.loadVideo(pendingVideoId, 0f);
                    pendingVideoId = null;
                }
            }

            @Override
            public void onError(@NonNull YouTubePlayer youTubePlayer, @NonNull PlayerConstants.PlayerError error) {
                // In caso di errore vogliamo lo stesso comportamento del trailer mancante:
                // solo testo e non cliccabile
                setPlayerUnavailable();
            }
        });
    }

    private void setupOpenInYouTube() {
        if (btnOpenInYouTube == null) return;

        btnOpenInYouTube.setOnClickListener(v -> {
            if (currentVideoId == null || currentVideoId.trim().isEmpty()) return;
            openInYouTubeApp(currentVideoId);
        });
    }

    private void openInYouTubeApp(String videoId) {
        Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + videoId));
        if (appIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(appIntent);
            return;
        }

        Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + videoId));
        startActivity(webIntent);
    }

    private void setupEpisodesList() {
        episodeAdapter = new EpisodeAdapter();
        episodeAdapter.setOnEpisodeClickListener(ep -> startTrailer(true));

        rvEpisodes.setLayoutManager(new LinearLayoutManager(this));
        rvEpisodes.setAdapter(episodeAdapter);
        rvEpisodes.setHasFixedSize(false);
    }

    private void setupEpisodesToggle() {
        if (btnToggleEpisodes == null) return;

        setEpisodesVisible(true);
        btnToggleEpisodes.setOnClickListener(v -> setEpisodesVisible(!episodesVisible));
    }

    private void setEpisodesVisible(boolean visible) {
        episodesVisible = visible;

        if (rvEpisodes != null) {
            rvEpisodes.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
        if (btnToggleEpisodes != null) {
            btnToggleEpisodes.setText(visible ? "Nascondi" : "Mostra");
        }
    }

    private void setupFullscreen() {
        if (btnFullscreen == null) return;

        placeFullscreenButtonOverlay();
        btnFullscreen.setOnClickListener(v -> toggleFullscreen());
    }

    private void placeFullscreenButtonOverlay() {
        if (youtubePlayerView == null || btnFullscreen == null) return;

        ViewGroup parent = (ViewGroup) btnFullscreen.getParent();
        if (parent != null) parent.removeView(btnFullscreen);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(40), dp(40));
        lp.gravity = Gravity.BOTTOM | Gravity.END;

        // più in alto, così non si sovrappone alle icone YouTube
        lp.setMargins(dp(8), dp(8), dp(8), dp(56));

        btnFullscreen.setLayoutParams(lp);
        btnFullscreen.setClickable(true);
        btnFullscreen.setFocusable(true);

        youtubePlayerView.addView(btnFullscreen);

        btnFullscreen.bringToFront();
        ViewCompat.setElevation(btnFullscreen, dp(12));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toggleFullscreen() {
        if (isFullscreen) exitFullscreen();
        else enterFullscreen();
    }

    private void enterFullscreen() {
        if (isFullscreen) return;
        if (playerContainer == null || fullScreenViewContainer == null) return;

        isFullscreen = true;

        originalPlayerParent = (ViewGroup) playerContainer.getParent();
        if (originalPlayerParent != null) {
            originalPlayerIndex = originalPlayerParent.indexOfChild(playerContainer);
            originalPlayerLayoutParams = playerContainer.getLayoutParams();
            originalPlayerParent.removeView(playerContainer);
        }

        fullScreenViewContainer.setVisibility(View.VISIBLE);
        fullScreenViewContainer.addView(playerContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        if (toolbarDetail != null) toolbarDetail.setVisibility(View.GONE);
        if (scrollContent != null) scrollContent.setVisibility(View.GONE);

        playerContainer.setBackgroundColor(Color.BLACK);
        btnFullscreen.setImageResource(R.drawable.ic_fullscreen_exit);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        hideSystemUi();
    }

    private void exitFullscreen() {
        if (!isFullscreen) return;
        if (playerContainer == null || fullScreenViewContainer == null) return;

        isFullscreen = false;

        fullScreenViewContainer.removeView(playerContainer);
        fullScreenViewContainer.setVisibility(View.GONE);

        if (originalPlayerParent != null) {
            if (originalPlayerLayoutParams != null) {
                originalPlayerParent.addView(playerContainer, originalPlayerIndex, originalPlayerLayoutParams);
            } else {
                originalPlayerParent.addView(playerContainer, originalPlayerIndex);
            }
        }

        if (originalPlayerBackground != null) {
            playerContainer.setBackground(originalPlayerBackground);
        }

        if (toolbarDetail != null) toolbarDetail.setVisibility(View.VISIBLE);
        if (scrollContent != null) scrollContent.setVisibility(View.VISIBLE);

        btnFullscreen.setImageResource(R.drawable.ic_fullscreen);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        showSystemUi();
    }

    private void hideSystemUi() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void showSystemUi() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onBackPressed() {
        if (isFullscreen) exitFullscreen();
        else super.onBackPressed();
    }

    private void startTrailer(boolean userInitiated) {
        if (currentDetail == null) return;

        String trailerUrl = currentDetail.getTrailerEmbedUrl();
        if (trailerUrl == null || trailerUrl.trim().isEmpty()) {
            setPlayerUnavailable();
            return;
        }

        String videoId = extractYouTubeId(trailerUrl);
        if (videoId == null || videoId.trim().isEmpty()) {
            setPlayerUnavailable();
            return;
        }

        currentVideoId = videoId;

        setPlayerAvailable();
        playVideo(videoId);
    }

    private void playVideo(String videoId) {
        if (youTubePlayer != null) {
            youTubePlayer.loadVideo(videoId, 0f);
        } else {
            pendingVideoId = videoId;
        }
    }

    private void setPlayerUnavailable() {
        currentVideoId = null;
        pendingVideoId = null;

        if (playerContainer != null) {
            playerContainer.setBackgroundColor(Color.BLACK);
        }

        if (youtubePlayerView != null) {
            youtubePlayerView.setVisibility(View.GONE);
        }

        showPlayerMessage("Trailer non disponibile per questo anime");

        if (btnOpenInYouTube != null) btnOpenInYouTube.setVisibility(View.GONE);
        if (btnFullscreen != null) btnFullscreen.setVisibility(View.GONE);

        if (youTubePlayer != null) {
            try {
                youTubePlayer.pause();
            } catch (Exception ignored) { }
        }
    }

    private void setPlayerAvailable() {
        if (!isFullscreen && playerContainer != null && originalPlayerBackground != null) {
            playerContainer.setBackground(originalPlayerBackground);
        }

        if (youtubePlayerView != null) {
            youtubePlayerView.setVisibility(View.VISIBLE);
        }

        hidePlayerMessage();

        if (btnFullscreen != null) btnFullscreen.setVisibility(View.VISIBLE);
        if (btnOpenInYouTube != null) btnOpenInYouTube.setVisibility(View.GONE);
    }

    private void showPlayerMessage(@NonNull String message) {
        if (txtPlayerHint == null) return;

        txtPlayerHint.setText(message);
        txtPlayerHint.setVisibility(View.VISIBLE);

        // Importantissimo: intercetta i tocchi così non puoi cliccare il player sotto
        txtPlayerHint.setClickable(true);
        txtPlayerHint.setFocusable(true);
        txtPlayerHint.setOnTouchListener((v, event) -> true);
    }

    private void hidePlayerMessage() {
        if (txtPlayerHint == null) return;

        txtPlayerHint.setVisibility(View.GONE);
        txtPlayerHint.setOnTouchListener(null);
        txtPlayerHint.setClickable(false);
        txtPlayerHint.setFocusable(false);
    }

    private String extractYouTubeId(String url) {
        try {
            Uri uri = Uri.parse(url);

            String host = uri.getHost();
            if (host != null) host = host.toLowerCase();

            if (host != null && host.contains("youtu.be")) {
                String path = uri.getPath();
                if (path != null) {
                    String id = path.replace("/", "").trim();
                    if (!id.isEmpty()) return id;
                }
            }

            if (uri.getPath() != null && uri.getPath().contains("/embed/")) {
                String[] parts = uri.getPath().split("/embed/");
                if (parts.length == 2) {
                    String id = parts[1];
                    if (id.contains("?")) id = id.substring(0, id.indexOf("?"));
                    id = id.trim();
                    if (!id.isEmpty()) return id;
                }
            }

            String v = uri.getQueryParameter("v");
            if (v != null && !v.trim().isEmpty()) return v.trim();

        } catch (Exception ignored) { }
        return null;
    }

    private void observeVm() {
        viewModel.getLoading().observe(this, isLoading -> {
            progressDetail.setVisibility(Boolean.TRUE.equals(isLoading) ? View.VISIBLE : View.GONE);
        });

        viewModel.getError().observe(this, err -> {
            if (err == null || err.trim().isEmpty()) {
                txtError.setVisibility(View.GONE);
            } else {
                txtError.setText(err);
                txtError.setVisibility(View.VISIBLE);
            }
        });

        viewModel.getAnimeDetail().observe(this, detail -> {
            currentDetail = detail;
            if (detail == null) return;

            txtAnimeTitle.setText(detail.getTitle());
            txtTotalEpisodes.setText("Episodi totali: " + detail.getTotalEpisodes());

            List<String> genres = detail.getGenres();
            if (genres == null || genres.isEmpty()) {
                txtGenres.setText("Generi: -");
            } else {
                txtGenres.setText("Generi: " + android.text.TextUtils.join(", ", genres));
            }

            txtSynopsis.setText(detail.getSynopsis());

            startTrailer(false);
            applyEpisodes(lastEpisodesFromApi);
        });

        viewModel.getEpisodes().observe(this, this::applyEpisodes);
    }

    private void applyEpisodes(List<Episode> listFromApi) {
        lastEpisodesFromApi = listFromApi;

        List<Episode> toShow = listFromApi;
        if ((toShow == null || toShow.isEmpty()) && currentDetail != null) {
            toShow = buildFallbackEpisodes(currentDetail);
        }

        episodeAdapter.setEpisodes(toShow);
    }

    private List<Episode> buildFallbackEpisodes(@NonNull AnimeDetail detail) {
        int total = detail.getTotalEpisodes();
        if (total <= 0) total = 1;

        int max = Math.min(total, 200);

        List<Episode> out = new ArrayList<>();
        if (max == 1) {
            out.add(new Episode(1, "Film"));
            return out;
        }

        for (int i = 1; i <= max; i++) {
            out.add(new Episode(i, "Episodio " + i));
        }
        return out;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            if (isFullscreen) {
                exitFullscreen();
                return true;
            }
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        if (youtubePlayerView != null) {
            youtubePlayerView.release();
        }
        super.onDestroy();
    }
}
