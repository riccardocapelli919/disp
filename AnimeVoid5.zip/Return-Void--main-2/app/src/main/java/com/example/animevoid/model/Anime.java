package com.example.animevoid.model;

import java.io.Serializable;

public class Anime implements Serializable {

    private int id;
    private String title;
    private String imageUrl;

    public Anime(int id, String title, String imageUrl) {
        this.id = id;
        this.title = title;
        this.imageUrl = imageUrl;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}