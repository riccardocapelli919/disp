package com.example.animevoid.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.animevoid.R;
import com.example.animevoid.model.Anime;
import com.example.animevoid.ui.streaming.AnimeDetailActivity;

import java.util.ArrayList;
import java.util.List;

public class WatchlistAdapter
        extends RecyclerView.Adapter<WatchlistAdapter.WatchlistViewHolder> {

    private final Context context;
    private final List<Anime> animeList = new ArrayList<>();

    // 🔹 COSTRUTTORE CORRETTO
    public WatchlistAdapter(Context context) {
        this.context = context;
    }

    // 🔹 SET DATI
    public void setAnimeList(List<Anime> list) {
        animeList.clear();
        if (list != null) {
            animeList.addAll(list);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public WatchlistViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_watchlist_anime, parent, false);
        return new WatchlistViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull WatchlistViewHolder holder,
            int position
    ) {
        Anime anime = animeList.get(position);

        holder.txtTitle.setText(anime.getTitle());

        Glide.with(context)
                .load(anime.getImageUrl())
                .placeholder(R.drawable.card_placeholder)
                .into(holder.imgCover);

        // 🔹 CLICK → scheda anime
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, AnimeDetailActivity.class);
            intent.putExtra("anime", anime);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return animeList.size();
    }

    // 🔹 VIEW HOLDER
    static class WatchlistViewHolder extends RecyclerView.ViewHolder {

        ImageView imgCover;
        TextView txtTitle;

        WatchlistViewHolder(@NonNull View itemView) {
            super(itemView);
            imgCover = itemView.findViewById(R.id.imgCover);
            txtTitle = itemView.findViewById(R.id.txtTitle);
        }
    }
}