package com.example.animevoid.data.remote.response;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class SearchAnimeResponse {

    @SerializedName("data")
    public List<AnimeDto> data;
}