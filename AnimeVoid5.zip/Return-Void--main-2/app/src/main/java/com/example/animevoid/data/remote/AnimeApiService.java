package com.example.animevoid.data.remote;

import com.example.animevoid.data.remote.response.TopAnimeResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface AnimeApiService {

    // TOP ANIME (Top 5)
    @GET("top/anime")
    Call<TopAnimeResponse> getTopAnime();

    // ANIME PER GENERE (Action, Romance, ecc.)
    @GET("anime")
    Call<TopAnimeResponse> getAnimeByGenre(
            @Query("genres") int genreId,
            @Query("limit") int limit
    );
}