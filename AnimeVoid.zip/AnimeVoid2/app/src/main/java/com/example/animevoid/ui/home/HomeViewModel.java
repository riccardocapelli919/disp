package com.example.animevoid.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.animevoid.data.repository.AnimeRepository;
import com.example.animevoid.data.repository.FakeAnimeRepository;
import com.example.animevoid.data.repository.RepositoryCallback;
import com.example.animevoid.model.Anime;
import com.example.animevoid.data.repository.AnimeRepositoryImpl;
import java.util.List;

public class HomeViewModel extends ViewModel {

    private final AnimeRepository repository;

    private final MutableLiveData<List<Anime>> top5Anime = new MutableLiveData<>();
    private final MutableLiveData<List<Anime>> actionAnime = new MutableLiveData<>();
    private final MutableLiveData<List<Anime>> romanceAnime = new MutableLiveData<>();
    private final MutableLiveData<List<Anime>> horrorAnime = new MutableLiveData<>();

    public HomeViewModel() {

        repository = new AnimeRepositoryImpl();

        repository.getTop5Anime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                top5Anime.setValue(data);
            }

            @Override
            public void onError(Throwable t) {
            }
        });

        repository.getActionAnime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                actionAnime.setValue(data);
            }

            @Override
            public void onError(Throwable t) {
            }
        });

        repository.getRomanceAnime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                romanceAnime.setValue(data);
            }

            @Override
            public void onError(Throwable t) {
            }
        });

        repository.getHorrorAnime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                horrorAnime.setValue(data);
            }

            @Override
            public void onError(Throwable t) {
            }
        });
    }

    // -------- GETTERS PER LA UI --------

    public LiveData<List<Anime>> getTop5Anime() {
        return top5Anime;
    }

    public LiveData<List<Anime>> getActionAnime() {
        return actionAnime;
    }

    public LiveData<List<Anime>> getRomanceAnime() {
        return romanceAnime;
    }

    public LiveData<List<Anime>> getHorrorAnime() {
        return horrorAnime;
    }
}
