package com.example.animevoid.ui.home.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.animevoid.R;
import com.example.animevoid.ui.auth.AuthActivity;
import com.example.animevoid.ui.auth.fragment.AuthViewModel;
import com.example.animevoid.utility.AnimeVoidText;
import com.google.android.material.snackbar.Snackbar;

public class ProfileFragment extends Fragment {

    private AuthViewModel viewModel;


    public ProfileFragment() {
        // Required empty public constructor
    }
    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        //Bundle args = new Bundle();
        //args.putString(ARG_PARAM1, param1);
        //args.putString(ARG_PARAM2, param2);
        //fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(AuthViewModel.class);

        TextView username = view.findViewById(R.id.txtUsername);
        AnimeVoidText.apply(username);


        // Bottone Impostazioni account
        Button btnImpostazioniAccount = view.findViewById(R.id.btnAccountSettings);
        btnImpostazioniAccount.setOnClickListener(v ->{

            NavController navController = Navigation.findNavController(view);

            navController.navigate(R.id.action_nav_profile_to_changeNameFragment);

        });

        // Impostazioni profilo

        ImageView imgProfile = view.findViewById(R.id.imgProfile);
        TextView txtEmail = view.findViewById(R.id.txtEmail);
        Button cambio_pass = view.findViewById(R.id.btnChangePassword);

        username.setText(viewModel.getUser());

        txtEmail.setText(viewModel.getEmail());

        Uri photoUrl = viewModel.getPhotoUrl();
        if (photoUrl != null) {
            Glide.with(this)
                    .load(photoUrl)
                    .placeholder(R.drawable.ic_profile_placeholder)
                    .error(R.drawable.ic_profile_placeholder)
                    .circleCrop()
                    .into(imgProfile);
        } else {
            imgProfile.setImageResource(R.drawable.ic_profile_placeholder);
        }

        cambio_pass.setOnClickListener(v -> {
            cambioPassword(viewModel);
        });

        // Osservazione Stato (Disabilito i bottoni se è in loading)

        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            boolean enabled = isLoading == null || !isLoading;
            cambio_pass.setEnabled(enabled);
        });

        // Osservazione messaggi

        viewModel.getMessage().observe(getViewLifecycleOwner(), msg -> {
            if (msg == null) return;
            showTopSnackbar(view, msg);
            viewModel.clearMessage();
        });

        setupLogout(view);

    }

    public void cambioPassword(AuthViewModel viewModel ) {
        viewModel.cambioPass(requireActivity());
    }

    private void showTopSnackbar(@NonNull View root, @NonNull String msg) {
        Snackbar sb = Snackbar.make(root, msg, Snackbar.LENGTH_LONG);
        sb.getView().setTranslationY(200);
        ((FrameLayout.LayoutParams) sb.getView().getLayoutParams()).gravity = Gravity.TOP;
        sb.show();
    }

    // Logout
    private void setupLogout(View view) {
        Button btnLogout = view.findViewById(R.id.logout);

        btnLogout.setOnClickListener(v -> viewModel.logout());

        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            boolean enabled = isLoading == null || !isLoading;
            btnLogout.setEnabled(enabled);
        });

        viewModel.getMessage().observe(getViewLifecycleOwner(), msg -> {
            if (msg == null) return;
            Snackbar.make(view, msg, Snackbar.LENGTH_LONG).show();
            viewModel.clearMessage();
        });

        viewModel.getNavigateHome().observe(getViewLifecycleOwner(), go -> {
            if (!Boolean.TRUE.equals(go)) return;

            Intent i = new Intent(requireContext(), AuthActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            requireActivity().finish();

            viewModel.navigationDone();
        });
    }
}