package com.example.animevoid.ui.auth.fragment;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.animevoid.data.auth.AuthManager;
import com.example.animevoid.data.auth.AuthRepository;
import com.google.firebase.auth.FirebaseUser;

public class AuthViewModel extends ViewModel {

    // creo qui il repository
    private final AuthRepository repository = new AuthRepository(AuthManager.getInstance());

    private final MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private final MutableLiveData<String> message = new MutableLiveData<>(null);
    private final MutableLiveData<Boolean> navigateHome = new MutableLiveData<>(false);
    private final MutableLiveData<FirebaseUser> currentUser = new MutableLiveData<>(repository.getCurrentUser());

    public LiveData<Boolean> getLoading() {
        return loading;
    }

    public LiveData<String> getMessage() {
        return message;
    }

    public LiveData<Boolean> getNavigateHome() {
        return navigateHome;
    }

    public LiveData<FirebaseUser> getCurrentUser() {
        return currentUser;
    }

    // La UI chiama questo dopo aver mostrato lo Snackbar
    public void clearMessage() {
        message.setValue(null);
    }

    // La UI chiama questo dopo aver navigato
    public void navigationDone() {
        navigateHome.setValue(false);
    }

    public void loginWithEmail(@NonNull Activity activity, @NonNull String email, @NonNull String password) {

        loading.setValue(true);

        repository.loginWithEmail(activity, email, password, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                loading.setValue(false);
                currentUser.setValue(user);
                navigateHome.setValue(true);
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });
    }

    public void loginWithGoogle(@NonNull Activity activity) {
        loading.setValue(true);

        repository.loginWithGoogle(activity, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                loading.setValue(false);
                currentUser.setValue(user);
                navigateHome.setValue(true);
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });
    }

    public void registerWithEmail(@NonNull Activity activity,
                                  @NonNull String username,
                                  @NonNull String email,
                                  @NonNull String password,
                                  @NonNull String confirmPassword) {

        if (password.isEmpty() || confirmPassword.isEmpty()) {
            message.setValue("Compila tutti i campi.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            message.setValue("Le password devono essere uguali.");
            return;
        }

        loading.setValue(true);

        repository.registerWithEmail(activity, username, email, password, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                loading.setValue(false);
                currentUser.setValue(user);
                navigateHome.setValue(true);
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });
    }

    public void resetPassword(@NonNull Activity activity, @NonNull String email, @NonNull String confirmEmail) {
        String e1 = email.trim();
        String e2 = confirmEmail.trim();

        if (e1.isEmpty() || e2.isEmpty()) {
            message.setValue("Inserisci e conferma l'email.");
            return;
        }

        if (!e1.equals(e2)) {
            message.setValue("Le email devono essere uguali.");
            return;
        }

        loading.setValue(true);

        repository.resetPassword(activity, e1, new AuthRepository.SimpleCallback() {
            @Override
            public void onSuccess() {
                loading.setValue(false);
                message.setValue("Se l'email è registrata, riceverai un link.");
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });
    }
}
