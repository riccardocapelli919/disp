package com.example.animevoid.data.repository;

import com.example.animevoid.data.remote.AnimeApiService;
import com.example.animevoid.data.remote.response.AnimeEpisodesResponse;
import com.example.animevoid.data.remote.response.AnimeFullResponse;
import com.example.animevoid.data.remote.response.SearchAnimeResponse;
import com.example.animevoid.data.remote.response.TopAnimeResponse;
import com.example.animevoid.data.remote.response.AnimeDto;
import com.example.animevoid.model.Anime;
import com.example.animevoid.model.AnimeDetail;
import com.example.animevoid.model.Episode;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AnimeRepositoryImpl implements AnimeRepository {

    private final AnimeApiService api;

    public AnimeRepositoryImpl() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.jikan.moe/v4/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api = retrofit.create(AnimeApiService.class);
    }

    // ================= TOP 5 =================

    @Override
    public void getTop5Anime(RepositoryCallback<List<Anime>> callback) {
        api.getTopAnime().enqueue(new retrofit2.Callback<TopAnimeResponse>() {
            @Override
            public void onResponse(Call<TopAnimeResponse> call,
                                   Response<TopAnimeResponse> response) {

                if (response.isSuccessful() && response.body() != null) {
                    callback.onSuccess(response.body().toAnimeList(5));
                } else {
                    callback.onError(new Throwable("API error"));
                }
            }

            @Override
            public void onFailure(Call<TopAnimeResponse> call, Throwable t) {
                callback.onError(t);
            }
        });
    }

    // ================= GENERI =================

    @Override
    public void getActionAnime(RepositoryCallback<List<Anime>> callback) {
        getByGenre(1, callback);   // Action
    }

    @Override
    public void getRomanceAnime(RepositoryCallback<List<Anime>> callback) {
        getByGenre(22, callback);  // Romance
    }



    private void getByGenre(int genreId,
                            RepositoryCallback<List<Anime>> callback) {

        api.getAnimeByGenre(genreId, 5)
                .enqueue(new Callback<TopAnimeResponse>() {
                    @Override
                    public void onResponse(Call<TopAnimeResponse> call,
                                           Response<TopAnimeResponse> response) {

                        if (response.isSuccessful() && response.body() != null) {
                            callback.onSuccess(map(response.body(), 5));
                        } else {
                            callback.onError(new Throwable("API error"));
                        }
                    }

                    @Override
                    public void onFailure(Call<TopAnimeResponse> call, Throwable t) {
                        callback.onError(t);
                    }
                });
    }

    // ================= MAPPER =================

    private List<Anime> map(TopAnimeResponse body, int limit) {
        if (body == null) return new ArrayList<>();
        return mapDtos(body.data, limit);
    }

    private List<Anime> mapDtos(List<AnimeDto> dtos, int limit) {
        List<Anime> result = new ArrayList<>();

        if (dtos == null) return result;

        int count = Math.min(limit, dtos.size());

        for (int i = 0; i < count; i++) {
            AnimeDto dto = dtos.get(i);

            String imageUrl = "";

            if (dto.images != null && dto.images.jpg != null) {
                if (dto.images.jpg.imageUrl != null) {
                    imageUrl = dto.images.jpg.imageUrl;
                } else if (dto.images.jpg.largeImageUrl != null) {
                    imageUrl = dto.images.jpg.largeImageUrl;
                }
            }

            result.add(new Anime(
                    dto.malId,
                    dto.title,
                    imageUrl
            ));
        }

        return result;
    }


    // Search

    @Override
    public void searchAnime(String query, RepositoryCallback<List<Anime>> callback) {
        String q = query == null ? "" : query.trim();

        if (q.isEmpty()) {
            callback.onSuccess(new ArrayList<>());
            return;
        }

        final int limit = 25;

        api.searchAnime(q, limit, true)
                .enqueue(new Callback<SearchAnimeResponse>() {
                    @Override
                    public void onResponse(Call<SearchAnimeResponse> call,
                                           Response<SearchAnimeResponse> response) {

                        if (response.isSuccessful() && response.body() != null) {
                            callback.onSuccess(mapDtos(response.body().data, limit));
                        } else {
                            callback.onError(new Throwable("API error: " + response.code()));
                        }
                    }

                    @Override
                    public void onFailure(Call<SearchAnimeResponse> call, Throwable t) {
                        callback.onError(t);
                    }
                });
    }


    // Prende i dettagli di un anime
    @Override
    public void getAnimeDetails(int animeId, RepositoryCallback<AnimeDetail> callback) {
        api.getAnimeFull(animeId).enqueue(new retrofit2.Callback<AnimeFullResponse>() {
            @Override
            public void onResponse(retrofit2.Call<AnimeFullResponse> call, retrofit2.Response<AnimeFullResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    AnimeDetail detail = response.body().toAnimeDetail();
                    if (detail != null) {
                        callback.onSuccess(detail);
                    } else {
                        callback.onError(new Exception("Dettagli non disponibili"));
                    }
                } else {
                    callback.onError(new Exception("Errore API: " + response.code()));
                }
            }

            @Override
            public void onFailure(retrofit2.Call<AnimeFullResponse> call, Throwable t) {
                callback.onError(t);
            }
        });
    }

    @Override
    public void getAnimeEpisodes(int animeId, RepositoryCallback<List<Episode>> callback) {
        fetchEpisodesPage(animeId, 1, new ArrayList<>(), callback);
    }

    private void fetchEpisodesPage(int animeId, int page, List<Episode> acc, RepositoryCallback<List<Episode>> callback) {
        api.getAnimeEpisodes(animeId, page).enqueue(new retrofit2.Callback<AnimeEpisodesResponse>() {
            @Override
            public void onResponse(retrofit2.Call<AnimeEpisodesResponse> call, retrofit2.Response<AnimeEpisodesResponse> response) {
                if (!response.isSuccessful() || response.body() == null) {
                    callback.onError(new Exception("Errore API episodi: " + response.code()));
                    return;
                }

                AnimeEpisodesResponse body = response.body();
                acc.addAll(body.toEpisodeList());

                boolean hasNext = body.pagination != null && body.pagination.hasNextPage;
                if (hasNext) {
                    fetchEpisodesPage(animeId, page + 1, acc, callback);
                } else {
                    callback.onSuccess(acc);
                }
            }

            @Override
            public void onFailure(retrofit2.Call<AnimeEpisodesResponse> call, Throwable t) {
                callback.onError(t);
            }
        });
    }


}