package com.example.animevoid.data.repository;

import com.example.animevoid.model.Anime;

import java.util.ArrayList;
import java.util.List;

public class FakeAnimeRepository implements AnimeRepository {

    @Override
    public void getTop5Anime(RepositoryCallback<List<Anime>> callback) {
        callback.onSuccess(new ArrayList<>(fakeTop5()));
    }

    @Override
    public void getActionAnime(RepositoryCallback<List<Anime>> callback) {
        callback.onSuccess(new ArrayList<>(fakeAction()));
    }

    @Override
    public void getRomanceAnime(RepositoryCallback<List<Anime>> callback) {
        callback.onSuccess(new ArrayList<>(fakeRomance()));
    }

    // ------------------------
    // FAKE DATA
    // ------------------------

    private List<Anime> fakeTop5() {
        List<Anime> list = new ArrayList<>();
        list.add(new Anime(1, "Attack on Titan", ""));
        list.add(new Anime(2, "Demon Slayer", ""));
        list.add(new Anime(3, "Jujutsu Kaisen", ""));
        list.add(new Anime(4, "One Piece", ""));
        list.add(new Anime(5, "Death Note", ""));
        return list;
    }

    private List<Anime> fakeAction() {
        List<Anime> list = new ArrayList<>();
        list.add(new Anime(10, "Naruto", ""));
        list.add(new Anime(11, "Bleach", ""));
        list.add(new Anime(12, "Dragon Ball Z", ""));
        return list;
    }

    private List<Anime> fakeRomance() {
        List<Anime> list = new ArrayList<>();
        list.add(new Anime(20, "Your Name", ""));
        list.add(new Anime(21, "Toradora", ""));
        list.add(new Anime(22, "Clannad", ""));
        return list;
    }

    private List<Anime> fakeHorror() {
        List<Anime> list = new ArrayList<>();
        list.add(new Anime(30, "Tokyo Ghoul", ""));
        list.add(new Anime(31, "Another", ""));
        list.add(new Anime(32, "Parasyte", ""));
        return list;
    }
}