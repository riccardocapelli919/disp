package com.example.animevoid.ui.home;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animevoid.R;
import com.example.animevoid.adapter.AnimeAdapter;
import com.example.animevoid.adapter.Top5Adapter;
import com.example.animevoid.data.repository.AnimeRepository;
import com.example.animevoid.data.repository.AnimeRepositoryImpl;
import com.example.animevoid.data.repository.RepositoryCallback;
import com.example.animevoid.model.Anime;

import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private Top5Adapter top5Adapter;
    private AnimeAdapter actionAdapter;
    private AnimeAdapter romanceAdapter;
    private AnimeAdapter horrorAdapter;

    private AnimeRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // ================= TOP 5 =================
        RecyclerView recyclerTop5 = findViewById(R.id.recyclerTop5);
        recyclerTop5.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recyclerTop5.setHasFixedSize(true);
        recyclerTop5.setNestedScrollingEnabled(false);

        top5Adapter = new Top5Adapter();
        recyclerTop5.setAdapter(top5Adapter);

        // ================= AZIONE (VUOTO PER ORA) =================
        RecyclerView recyclerAction = findViewById(R.id.recyclerAction);
        recyclerAction.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recyclerAction.setHasFixedSize(true);
        recyclerAction.setNestedScrollingEnabled(false);

        actionAdapter = new AnimeAdapter();
        recyclerAction.setAdapter(actionAdapter);

        // ================= ROMANCE (VUOTO PER ORA) =================
        RecyclerView recyclerRomance = findViewById(R.id.recyclerRomance);
        recyclerRomance.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recyclerRomance.setHasFixedSize(true);
        recyclerRomance.setNestedScrollingEnabled(false);

        romanceAdapter = new AnimeAdapter();
        recyclerRomance.setAdapter(romanceAdapter);

        // ================= HORROR (VUOTO PER ORA) =================
        RecyclerView recyclerHorror = findViewById(R.id.recyclerHorror);
        recyclerHorror.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recyclerHorror.setHasFixedSize(true);
        recyclerHorror.setNestedScrollingEnabled(false);

        horrorAdapter = new AnimeAdapter();
        recyclerHorror.setAdapter(horrorAdapter);

        // ================= REPOSITORY =================
        repository = new AnimeRepositoryImpl();

        // ================= CHIAMATA API (SOLO TOP 5) =================
        repository.getTop5Anime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                top5Adapter.setAnimeList(data);
            }

            @Override
            public void onError(Throwable t) {
                Log.e("API", t.getMessage());
            }
        });
    }
}