package com.example.animevoid;

import android.app.Application;
import com.example.animevoid.data.auth.AuthManager;

public class MyApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        AuthManager.getInstance().init(this);
    }
}
