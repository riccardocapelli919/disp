package com.example.animevoid.data.remote;

import com.example.animevoid.data.remote.response.AnimeEpisodesResponse;
import com.example.animevoid.data.remote.response.AnimeFullResponse;
import com.example.animevoid.data.remote.response.TopAnimeResponse;
import com.example.animevoid.data.remote.response.SearchAnimeResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface AnimeApiService {

    // TOP ANIME (Top 5)
    @GET("top/anime")
    Call<TopAnimeResponse> getTopAnime();

    // ANIME PER GENERE (Action, Romance, ecc.)
    @GET("anime")
    Call<TopAnimeResponse> getAnimeByGenre(
            @Query("genres") int genreId,
            @Query("limit") int limit
    );

    @GET("anime")
    Call<SearchAnimeResponse> searchAnime(
            @Query("q") String query,
            @Query("limit") int limit,
            @Query("sfw") boolean sfw
    );

    // DETTAGLI COMPLETI (include trailer)
    @GET("anime/{id}/full")
    Call<AnimeFullResponse> getAnimeFull(@Path("id") int animeId);

    // EPISODI (paginati)
    @GET("anime/{id}/episodes")
    Call<AnimeEpisodesResponse> getAnimeEpisodes(
            @Path("id") int animeId,
            @Query("page") int page
    );
}