package com.example.animevoid.ui.home.ViewModels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.animevoid.data.repository.AnimeRepository;
import com.example.animevoid.data.repository.AnimeRepositoryImpl;
import com.example.animevoid.data.repository.RepositoryCallback;
import com.example.animevoid.model.Anime;

import java.util.ArrayList;
import java.util.List;

public class HomeViewModel extends ViewModel {

    private final AnimeRepository repository = new AnimeRepositoryImpl();

    private final MutableLiveData<List<Anime>> top5Anime = new MutableLiveData<>();
    private final MutableLiveData<List<Anime>> actionAnime = new MutableLiveData<>();
    private final MutableLiveData<List<Anime>> romanceAnime = new MutableLiveData<>();

    private boolean loaded = false;

    public LiveData<List<Anime>> getTop5Anime() {
        loadIfNeeded();
        return top5Anime;
    }

    public LiveData<List<Anime>> getActionAnime() {
        loadIfNeeded();
        return actionAnime;
    }

    public LiveData<List<Anime>> getRomanceAnime() {
        loadIfNeeded();
        return romanceAnime;
    }


    // ================= CORE LOGIC =================

    private void loadIfNeeded() {
        if (loaded) return;
        loaded = true;

        loadTop5();
    }

    public void loadTop5() {
        repository.getTop5Anime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                top5Anime.postValue(data);
                loadAction(); // continua la catena
            }

            @Override
            public void onError(Throwable t) {
                top5Anime.postValue(new ArrayList<>());
                loadAction(); // continua comunque
            }
        });
    }

    private void loadAction() {
        repository.getActionAnime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                actionAnime.postValue(data);
                loadRomance();
            }

            @Override
            public void onError(Throwable t) {
                actionAnime.postValue(new ArrayList<>());
                loadRomance();
            }
        });
    }
    private void loadRomance() {
        repository.getRomanceAnime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                romanceAnime.postValue(data);
            }

            @Override
            public void onError(Throwable t) {
                romanceAnime.postValue(new ArrayList<>()); 
            }
        });
    }


}