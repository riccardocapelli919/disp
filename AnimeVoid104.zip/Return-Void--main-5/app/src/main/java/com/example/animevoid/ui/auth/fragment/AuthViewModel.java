package com.example.animevoid.ui.auth.fragment;

import android.app.Activity;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.animevoid.data.auth.AuthManager;
import com.example.animevoid.data.auth.AuthRepository;
import com.google.firebase.auth.FirebaseUser;

public class AuthViewModel extends ViewModel {

    // creo qui il repository
    private final AuthRepository repository = new AuthRepository(AuthManager.getInstance());

    private final MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private final MutableLiveData<String> message = new MutableLiveData<>(null);
    private final MutableLiveData<Boolean> navigateHome = new MutableLiveData<>(false);
    private final MutableLiveData<FirebaseUser> currentUser = new MutableLiveData<>(repository.getCurrentUser());

    private final MutableLiveData<Boolean> usernameUpdated = new MutableLiveData<>(false);



    public LiveData<Boolean> getUsernameUpdated() {
        return usernameUpdated;
    }

    public LiveData<Boolean> getLoading() {
        return loading;
    }

    public LiveData<String> getMessage() {
        return message;
    }

    public LiveData<Boolean> getNavigateHome() {
        return navigateHome;
    }

    public String getUser() {
        return repository.getUsername();
    }

    public Uri getPhotoUrl() {
        return repository.getProfilePhotoUrl();
    }

    public String getEmail() {
        return repository.getEmail();
    }

    public boolean hasUser() {
        return repository.hasUser();
    }

    public LiveData<FirebaseUser> getCurrentUser() {
        return currentUser;
    }

    public void usernameUpdateDone() {
        usernameUpdated.setValue(false);
    }

    // La UI chiama questo dopo aver mostrato lo Snackbar
    public void clearMessage() {
        message.setValue(null);
    }

    // La UI chiama questo dopo aver navigato
    public void navigationDone() {
        navigateHome.setValue(false);
    }

    public void loginWithEmail(@NonNull Activity activity, @NonNull String email, @NonNull String password) {

        loading.setValue(true);

        repository.loginWithEmail(activity, email, password, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                loading.setValue(false);
                currentUser.setValue(user);
                navigateHome.setValue(true);
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });
    }

    public void logout() {
        loading.setValue(true);

        repository.signOut(new AuthRepository.SimpleCallback() {
            @Override
            public void onSuccess() {
                loading.setValue(false);
                navigateHome.setValue(true);
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                // È una soft error: mostro msg ma navigo comunque
                loading.setValue(false);
                message.setValue(msg);
                navigateHome.setValue(true);
            }
        });
    }

    public void loginWithGoogle(@NonNull Activity activity) {
        loading.setValue(true);

        repository.loginWithGoogle(activity, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                loading.setValue(false);
                currentUser.setValue(user);
                navigateHome.setValue(true);
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });
    }

    public void registerWithEmail(@NonNull Activity activity,
                                  @NonNull String username,
                                  @NonNull String email,
                                  @NonNull String password,
                                  @NonNull String confirmPassword) {

        if (password.isEmpty() || confirmPassword.isEmpty()) {
            message.setValue("Compila tutti i campi.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            message.setValue("Le password devono essere uguali.");
            return;
        }

        loading.setValue(true);

        repository.registerWithEmail(activity, username, email, password, new AuthRepository.AuthCallback() {
            @Override
            public void onSuccess(@NonNull FirebaseUser user) {
                loading.setValue(false);
                currentUser.setValue(user);
                navigateHome.setValue(true);
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });
    }

    public void resetPassword(@NonNull Activity activity, @NonNull String email, @NonNull String confirmEmail) {
        String e1 = email.trim();
        String e2 = confirmEmail.trim();

        if (e1.isEmpty() || e2.isEmpty()) {
            message.setValue("Inserisci e conferma l'email.");
            return;
        }

        if (!e1.equals(e2)) {
            message.setValue("Le email devono essere uguali.");
            return;
        }

        loading.setValue(true);

        repository.resetPassword(activity, e1, new AuthRepository.SimpleCallback() {
            @Override
            public void onSuccess() {
                loading.setValue(false);
                message.setValue("Se l'email è registrata, riceverai un link nella tua email.");
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });
    }

    public void cambioPass (@NonNull Activity activity){
        String email = getEmail();
        loading.setValue(true);

        repository.resetPassword(activity, email, new AuthRepository.SimpleCallback() {
            @Override
            public void onSuccess() {
                loading.setValue(false);
                message.setValue("Riceverai un link nella tua email.");
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });

    }

    public void cambioUsername(@NonNull Activity activity, @NonNull String newUsername) {
        String clean = newUsername.trim();

        if (clean.isEmpty()) {
            message.setValue("Inserisci uno username valido.");
            return;
        }

        loading.setValue(true);

        repository.updateUsername(activity, clean, new AuthRepository.SimpleCallback() {
            @Override
            public void onSuccess() {
                loading.setValue(false);

                // Aggiorno lo user in memoria del ViewModel
                currentUser.setValue(repository.getCurrentUser());

                message.setValue("Username aggiornato.");
                usernameUpdated.setValue(true);
            }

            @Override
            public void onError(@NonNull String msg, Exception exception) {
                loading.setValue(false);
                message.setValue(msg);
            }
        });
    }



}
