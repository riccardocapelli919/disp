package com.example.animevoid.data.repository;

import com.example.animevoid.model.Anime;
import com.example.animevoid.model.AnimeDetail;
import com.example.animevoid.model.Episode;

import java.util.List;

public interface AnimeRepository {

    void getTop5Anime(RepositoryCallback<List<Anime>> callback);

    void getActionAnime(RepositoryCallback<List<Anime>> callback);

    void getRomanceAnime(RepositoryCallback<List<Anime>> callback);

    void searchAnime(String query, RepositoryCallback<List<Anime>> callback);

    void getAnimeDetails(int animeId, RepositoryCallback<AnimeDetail> callback);

    void getAnimeEpisodes(int animeId, RepositoryCallback<List<Episode>> callback);


}
