package com.example.animevoid.ui.home.ViewModels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.animevoid.R;
import com.example.animevoid.data.repository.AnimeRepository;
import com.example.animevoid.data.repository.AnimeRepositoryImpl;
import com.example.animevoid.data.repository.RepositoryCallback;
import com.example.animevoid.model.Anime;

import java.util.ArrayList;
import java.util.List;

public class SearchViewModel extends ViewModel {

    private final AnimeRepository repository = new AnimeRepositoryImpl();

    private final MutableLiveData<List<Anime>> results = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private final MutableLiveData<Integer> messageRes = new MutableLiveData<>(null);

    private String lastQuery = "";

    public LiveData<List<Anime>> getResults() { return results; }
    public LiveData<Boolean> getLoading() { return loading; }
    public LiveData<Integer> getMessageRes() { return messageRes; }

    public void clearMessage() { messageRes.setValue(null); }

    public void clearResults() {
        lastQuery = "";
        results.setValue(new ArrayList<>());
    }

    public void search(String query) {
        String q = query == null ? "" : query.trim();

        if (q.isEmpty()) {
            clearResults();
            messageRes.setValue(R.string.inserisci_testo_ricerca);
            return;
        }

        // evita doppie chiamate identiche
        if (q.equalsIgnoreCase(lastQuery)) return;

        lastQuery = q;
        loading.setValue(true);

        repository.searchAnime(q, new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                loading.postValue(false);
                results.postValue(data != null ? data : new ArrayList<>());

                if (data == null || data.isEmpty()) {
                    messageRes.postValue(R.string.nessun_risultato);
                }
            }

            @Override
            public void onError(Throwable t) {
                loading.postValue(false);
                results.postValue(new ArrayList<>());
                messageRes.postValue(R.string.errore_ricerca);
            }
        });
    }
}
