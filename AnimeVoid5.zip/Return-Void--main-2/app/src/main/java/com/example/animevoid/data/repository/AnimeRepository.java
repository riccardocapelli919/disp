package com.example.animevoid.data.repository;

import com.example.animevoid.model.Anime;
import java.util.List;

public interface AnimeRepository {

    void getTop5Anime(RepositoryCallback<List<Anime>> callback);

    void getActionAnime(RepositoryCallback<List<Anime>> callback);

    void getRomanceAnime(RepositoryCallback<List<Anime>> callback);

}
