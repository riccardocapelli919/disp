package com.example.animevoid.ui.streaming.ViewModels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.animevoid.data.repository.AnimeRepository;
import com.example.animevoid.data.repository.AnimeRepositoryImpl;
import com.example.animevoid.data.repository.RepositoryCallback;
import com.example.animevoid.model.AnimeDetail;
import com.example.animevoid.model.Episode;

import java.util.ArrayList;
import java.util.List;

public class AnimeDetailViewModel extends ViewModel {

    private final AnimeRepository repository = new AnimeRepositoryImpl();

    private final MutableLiveData<AnimeDetail> animeDetail = new MutableLiveData<>();
    private final MutableLiveData<List<Episode>> episodes = new MutableLiveData<>();
    private final MutableLiveData<Boolean> loading = new MutableLiveData<>(false);

    // error solo per il dettaglio (così gli errori dell'endpoint episodi non "rompono" i movie)
    private final MutableLiveData<String> error = new MutableLiveData<>(null);

    private int pendingCalls = 0;

    public LiveData<AnimeDetail> getAnimeDetail() {
        return animeDetail;
    }

    public LiveData<List<Episode>> getEpisodes() {
        return episodes;
    }

    public LiveData<Boolean> getLoading() {
        return loading;
    }

    public LiveData<String> getError() {
        return error;
    }

    public void load(int animeId) {
        error.setValue(null);
        loading.setValue(true);
        pendingCalls = 2;

        repository.getAnimeDetails(animeId, new RepositoryCallback<AnimeDetail>() {
            @Override
            public void onSuccess(AnimeDetail data) {
                animeDetail.postValue(data);
                error.postValue(null);
                markDone();
            }

            @Override
            public void onError(Throwable t) {
                error.postValue(t != null ? t.getMessage() : "Errore sconosciuto");
                markDone();
            }
        });

        repository.getAnimeEpisodes(animeId, new RepositoryCallback<List<Episode>>() {
            @Override
            public void onSuccess(List<Episode> data) {
                episodes.postValue(data);
                markDone();
            }

            @Override
            public void onError(Throwable t) {
                // Per molti movie l'endpoint episodi ritorna vuoto/errore: non mostriamo errori,
                // e lasciamo che la UI generi una lista fallback basata su totalEpisodes.
                episodes.postValue(new ArrayList<>());
                markDone();
            }
        });
    }

    private synchronized void markDone() {
        pendingCalls--;
        if (pendingCalls <= 0) {
            loading.postValue(false);
        }
    }
}
