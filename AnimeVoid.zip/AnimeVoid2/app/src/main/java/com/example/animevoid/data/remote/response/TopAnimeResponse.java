package com.example.animevoid.data.remote.response;

import com.example.animevoid.model.Anime;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;

public class TopAnimeResponse {

    @SerializedName("data")
    public List<AnimeDto> data;

    public List<Anime> toAnimeList(int limit) {
        List<Anime> list = new ArrayList<>();
        if (data == null) return list;

        for (int i = 0; i < Math.min(limit, data.size()); i++) {
            list.add(data.get(i).toAnime());
        }
        return list;
    }
}