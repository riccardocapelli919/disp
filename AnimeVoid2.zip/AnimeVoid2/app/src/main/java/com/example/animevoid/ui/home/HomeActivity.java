package com.example.animevoid.ui.home;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.animevoid.R;
import com.example.animevoid.adapter.AnimeAdapter;
import com.example.animevoid.adapter.Top5Adapter;
import com.example.animevoid.data.repository.AnimeRepository;
import com.example.animevoid.data.repository.AnimeRepositoryImpl;
import com.example.animevoid.data.repository.RepositoryCallback;
import com.example.animevoid.model.Anime;

import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private AnimeRepository repository;

    private Top5Adapter top5Adapter;
    private AnimeAdapter actionAdapter;
    private AnimeAdapter romanceAdapter;
    private AnimeAdapter horrorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        repository = new AnimeRepositoryImpl();

        setupTop5();
        setupAction();
        setupRomance();
        setupHorror();
    }

    // ================= TOP 5 =================
    private void setupTop5() {
        RecyclerView recyclerTop5 = findViewById(R.id.recyclerTop5);
        recyclerTop5.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recyclerTop5.setHasFixedSize(true);
        recyclerTop5.setNestedScrollingEnabled(false);

        top5Adapter = new Top5Adapter();
        recyclerTop5.setAdapter(top5Adapter);

        repository.getTop5Anime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                top5Adapter.setAnimeList(data);
            }

            @Override
            public void onError(Throwable t) {
                Log.e("TOP5", t.getMessage());
            }
        });
    }

    // ================= AZIONE =================
    private void setupAction() {
        RecyclerView recycler = findViewById(R.id.recyclerAction);
        recycler.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        actionAdapter = new AnimeAdapter();
        recycler.setAdapter(actionAdapter);

        repository.getActionAnime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                actionAdapter.setAnimeList(data);
            }

            @Override
            public void onError(Throwable t) {
                Log.e("ACTION", t.getMessage());
            }
        });
    }

    // ================= ROMANCE =================
    private void setupRomance() {
        RecyclerView recycler = findViewById(R.id.recyclerRomance);
        recycler.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        romanceAdapter = new AnimeAdapter();
        recycler.setAdapter(romanceAdapter);

        repository.getRomanceAnime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                romanceAdapter.setAnimeList(data);
            }

            @Override
            public void onError(Throwable t) {
                Log.e("ROMANCE", t.getMessage());
            }
        });
    }

    // ================= HORROR =================
    private void setupHorror() {
        RecyclerView recycler = findViewById(R.id.recyclerHorror);
        recycler.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );
        recycler.setHasFixedSize(true);
        recycler.setNestedScrollingEnabled(false);

        horrorAdapter = new AnimeAdapter();
        recycler.setAdapter(horrorAdapter);

        repository.getHorrorAnime(new RepositoryCallback<List<Anime>>() {
            @Override
            public void onSuccess(List<Anime> data) {
                horrorAdapter.setAnimeList(data);
            }

            @Override
            public void onError(Throwable t) {
                Log.e("HORROR", t.getMessage());
            }
        });
    }
}